<script setup lang="ts">
import '../../css/menu.css'
import { useMenuStore } from '../../store/menu'
import { useStoreToast } from '../../store/toast';
import { useLoginStore } from '../../store/login';
import router from '@/router';
import axios from 'axios';
import { ref } from 'vue';


const store = useMenuStore()

const storeToast = useStoreToast()
const storeLogin = useLoginStore()
const user = storeLogin.getUser();
const loading = ref(false);

const dialog = ref(false);
const anterior = ref('');
const nueva = ref('');
const repetir = ref('');
const message = ref('');

const logOut = () => {
  resetStores()
  storeLogin.logout();
  axios.post(`${storeLogin.link}/logout`).then(_ => {
    router.push('/login');
  }).catch(_ => {
    router.push('/login')
  })
}
const resetStores = () => {
  storeToast.reset()
  storeLogin.userlogin.reset()
  storeLogin.data.reset()
}
const menu = store.filtrarMenu(user);

const cambiar = () => {
  message.value = '';
  dialog.value = true;
}

const cambioContrasena = () => {
  loading.value = true;
  let usuario = storeLogin.getUser();
  if (!anterior.value || !nueva.value || !repetir.value) {
    message.value = 'Se debe Llenar todos los datos';
    return;
  }
  if (nueva.value != repetir.value) {
    message.value = 'La contraseña anterior y la nueva deben ser igual';
    return;
  }
  axios.get(`${storeLogin.link}/scap/inventario/usuario/cambiar-contrasena/${usuario.username}/${anterior.value}/${nueva.value}`)
    .then(data => {
      dialog.value = false;
      storeToast.muestraNotificacion('Cambio contraseña', 'Cambiado correctamente');
      loading.value = false;
      anterior.value = nueva.value = repetir.value = '';
    }).catch(error => {
      storeToast.muestraNotificacion('Cambio Contraseña', 'No se pudo cambiar la contraseña');
      loading.value = false;
    })
}

</script>
<template>
  <div class="container-menu" id="container-menu">
    <hr>
    <div class="inner-menu" id="innerMenu">
      <input type="radio" name="sub1" id="cerrar" checked>
      <div class="more up bold l blanco-t" id="up"></div>
      <div class="more down bold l blanco-t" id="down"></div>
      <template v-for="(itemMenu, indexM) in menu ">
        <div class="wrapper-btn-menu" :id="'btn-menu' + indexM">
          <button class="btn-menu transparente-b">
            <i class="xl amarillo-palido-t" :class="itemMenu.icono"></i>
            <span class="titulo-menu amarillo-palido-t xxs enfasis normal">{{ itemMenu.titulo }}</span>
          </button>
          <div class="indicador" :id="'in' + indexM"></div>
          <div class="submenu" :id="'menu' + indexM">
            <div class="elementos-submenu">
              <template v-for="(subItem, indexI) in itemMenu.elementos" v-bind:key="subItem">
                <div class="sub-wrap">
                  <template v-if="subItem.elementos">
                    <div class="subitem">
                      <input type="radio" name="sub1" :id="indexM + 'item' + indexI">
                      <label for="close" class="close-accordion"></label>
                      <label :for="indexM + 'item' + indexI"
                        class="boton enfasis xs  transparente-b blanco titulo-subitem"
                        style="--bg:var(--amarillo-palido30); --texto:var(--blanco);">
                        {{ subItem.titulo }}
                      </label>
                      <div class="subitems-wrapper amarillo-oscuro30-b"
                        :style="'--tam: ' + (subItem.elementos.length + 1) * 30 + 'px'">
                        <template v-for="elem in subItem.elementos" v-bind:key="elem">
                          <router-link :to="elem.vinculo ? { path: elem.vinculo } : '#'">
                            <button class="boton-subitem texto xs blanco-t transparente-b">
                              {{ elem.titulo }}
                            </button>
                          </router-link>
                        </template>
                      </div>
                    </div>
                  </template>
                  <template v-if="!subItem.elementos">
                    <router-link :to="subItem.vinculo ? { path: subItem.vinculo } : '#'">
                      <button class="boton enfasis xs  transparente-b blanco-t a100"
                        style="--bg:var(--amarillo-palido30); --texto:var(--blanco);"
                        v-on:click="$emit('notificacion', subItem.vinculo, 'Texto pasado desde el menu', '\f36d')">
                        {{ subItem.titulo }}
                      </button>
                    </router-link>
                  </template>
                </div>
              </template>
            </div>
          </div>
        </div>
      </template>
    </div>

    <hr>
    <div class="logout-btn">
      <div>
        <button class="boton anima logout xs enfasis bold" v-on:click="cambiar"
          style="--color: var(--primario); --texto:var(--negro)">
          Cambiar contraseña
        </button>
      </div>
      <div>
        <button class="boton anima logout xs enfasis bold" v-on:click="logOut"
          style="--color: var(--primario); --texto:var(--negro)">
          Cerrar sesión
        </button>
      </div>
    </div>
  </div>
  <Dialog v-model:visible="dialog" :modal="true" class="recover-modal" :dismissable-mask="true" @hide="!dialog">
    <template v-if="!loading">
      <div class="elemento-formulario">
        <div>{{ message }}</div>
        <div class="el-input">
          <label class=" texto etiqueta-input  blanco-t s titulo-etiqueta-requerido">Contraseña Anterior</label>
          <Password v-model="anterior"></Password>
        </div>
        <div class="el-input">
          <label class=" texto etiqueta-input  blanco-t s titulo-etiqueta-requerido">Contraseña Nueva</label>
          <Password v-model="nueva"></Password>
        </div>
        <div class="el-input">
          <label class=" texto etiqueta-input  blanco-t s titulo-etiqueta-requerido">Repetir Contraseña Nueva</label>
          <Password v-model="repetir"></Password>
        </div>
      </div>
      <div class="boton-guardar">
        <button class="boton enfasis negro-t primario-b anima s bold"
          style="--color: var(--primario); --texto:var(--negro)" v-on:click="cambioContrasena">Guardar</button>
      </div>
    </template>
    <div v-else>
      Cargando ...
    </div>
</Dialog>
</template>
<style scoped>
* {
  text-decoration: none;
}
</style>
