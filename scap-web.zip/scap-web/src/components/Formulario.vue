<script lang="ts">
import '../css/formulario.css'
import '../css/toast.css'
import { defineComponent, ref } from 'vue';
import InputText from 'primevue/inputtext';
import InputMask from 'primevue/inputmask';
import InputNumber from 'primevue/inputnumber';
import Chips from 'primevue/chips';
import Dropdown from 'primevue/dropdown';
import InputSwitch from 'primevue/inputswitch';
import SelectButton from 'primevue/selectbutton';
import FileUpload from 'primevue/fileupload';
import DataTable, { type DataTableRowEditCancelEvent } from 'primevue/datatable';
import Column from 'primevue/column';
import Dialog from 'primevue/dialog';
import axios, { type AxiosResponse } from 'axios';
import { Motion, Presence } from 'motion/vue'
import Calendar from 'primevue/calendar';
import moment from 'moment'

import { useToast } from 'primevue/usetoast';
import { useLoginStore } from '@/store/login';
import ConfirmDialog from 'primevue/confirmdialog';


export default defineComponent({
    name: 'Formulario',
    props: {
        data: {
            type: Object,
            required: true
        },
        tipo: {
            type: String,
            required: false
        },
        url: {
            type: String,
            required: true
        },
        acciones: {
            type: Array,
            required: false
        },
        masivo: {
            type: Array,
            required: false
        }
    },
    components: {
        Dropdown,
        InputSwitch,
        SelectButton,
        FileUpload,
        DataTable,
        Column,
        InputText,
        Dialog,
        Motion,
        Presence,
        ConfirmDialog,
        Calendar,
        InputMask,
        InputNumber
    },
    setup(props) {
        const storeToast = useToast()
        const storeLogin = useLoginStore()
        let local = ref({
            lastUrl: props.url,
            selectedRow: <any>undefined,
            selectedRows: [],
            loading: false,
            guardando: false,
            cargandoAccion: false,
            globalValor: '',
            globalCampo: props.data?.global?.campo,
            globalEtiqueta: props.data?.global?.etiqueta,
            globalOpciones: [] as { nombre: string, valor: string }[],
            pagina: 0,
            tamano: 10,
            total: 0,
            agregar: false,
            modal: false,
            modalMessage: '',
            agregarForm: () => {
                local.value.selectedRow = {};
                local.value.agregar = true;
            },
            data: [],
            acciones: props.acciones || [],
            masivo: props.masivo || [],
            getData: () => {
                let url = '?pagina=' + local.value.pagina + '&tamano=' + local.value.tamano;
                if (local.value.globalCampo) {
                    url += '&' + local.value.globalCampo + '=' + local.value.globalValor;
                }
                props.data.campos.forEach((element: any) => {
                    if (element.filterValue) {
                        url += '&' + encodeURIComponent(element.nombreCampo) + '=' + encodeURIComponent(element.filterValue);
                    }
                });
                if (props.data.filtro)
                    for (let label in props.data.filtro)
                        url += '&' + encodeURIComponent(label) + '=' + encodeURIComponent(props.data.filtro[label]);
                local.value.loading = true;
                axios.get(props.url.trim() + url, { withCredentials: true }).then((data: AxiosResponse) => {
                    local.value.loading = false;
                    local.value.data = data.data
                }, (error) => {
                    local.value.loading = false;
                    console.log(error)
                })
                axios.get(props.url.trim() + '/count' + url, { withCredentials: true }).then((data: AxiosResponse) => {
                    local.value.total = data.data
                }, error => {
                    console.error(error);
                })
            },
            reload: (force = false) => {
                let diferent = local.value.lastUrl != props.url
                if (diferent) {
                    local.value.lastUrl = props.url;
                    local.value.globalCampo = props.data?.global?.campo
                    local.value.globalEtiqueta = props.data?.global?.etiqueta
                    local.value.globalOpciones = [] as { nombre: string, valor: string }[]
                }
                if (diferent || force) {
                    if (local.value.globalCampo) {
                        let url = props.url.trim() + '/global?valor=' + local.value.globalCampo
                        props.data.campos.forEach((element: any) => {
                            if (element.filterValue) {
                                url += '&' + encodeURIComponent(element.nombreCampo) + '=' + encodeURIComponent(element.filterValue);
                            }
                        })
                        if (props.data.filtro)
                            for (let label in props.data.filtro)
                                url += '&' + encodeURIComponent(label) + '=' + encodeURIComponent(props.data.filtro[label]);
                        local.value.loading = true;
                        axios.get(url, { withCredentials: true }).then((data: AxiosResponse) => {
                            local.value.loading = false;
                            if (Array.isArray(data.data)) {
                                local.value.globalOpciones = data.data.map(str => ({ nombre: str, valor: str }))
                                if ((data.data.length && diferent) || !local.value.globalValor)
                                    local.value.globalValor = data.data[0];
                            }

                            local.value.pagina = 0;
                            console.log('get inner data');
                            local.value.getData();
                            local.value.acciones = props.acciones || [];
                            local.value.masivo = props.masivo || [];
                        }, (error) => {
                            local.value.loading = false;
                            console.log(error)
                        })
                    } else {
                        console.log('getData');
                        local.value.lastUrl = props.url;
                        local.value.pagina = 0;
                        local.value.getData();
                        local.value.acciones = props.acciones || [];
                        local.value.masivo = props.masivo || [];
                    }
                }
            },
            async guardarMasivo(data: { [label: string]: string }[], campo: string, valor: any, campoObservacion: any, textoObservacion: any, validacion: (value: string) => boolean) {
                if (!data)
                    return;
                local.value.loading = true;
                let observacion;
                console.log(campoObservacion, textoObservacion)
                if (campoObservacion) {
                    observacion = prompt(textoObservacion ?? 'Escriba el motivo por favor') ?? '';
                    if (validacion && !validacion(observacion)) {
                        alert('El valor "' + observacion + '" es incorrecto');
                        return;
                    }
                }
                for (let registro of data) {
                    registro[campo] = valor;
                    if (observacion)
                        registro[campoObservacion] = observacion;
                    await local.value.save(registro);
                }
                data.splice(0);
                local.value.reload(true);
            },
            save: async (data: any, showLoading = false) => {
                if (showLoading)
                    local.value.loading = true;
                const url = props.url;
                await axios.post(url, data, { withCredentials: true }).then((data) => {
                    storeToast.add({
                        detail: 'Guardado Correctamente',
                        summary: 'Guardar',
                        life: 2000,
                        closable: true
                    })
                    local.value.agregar = false;
                    if (showLoading) {
                        local.value.loading = false;
                    }
                    local.value.reload(showLoading);
                }).catch(error => {
                    let mensaje = '';
                    if(error.mensaje)
                        mensaje = error.mensae;
                    else if(error?.response?.data?.mensaje)
                        mensaje = error.response.data.mensaje;
                    else
                        mensaje = 'No se pudo guardar';

                    storeToast.add({
                        detail: mensaje,
                        summary: 'Guardando',
                        life: 20000,
                        closable: true
                    })
                });
            },
            next: () => {
                local.value.pagina = local.value.pagina + 1
                local.value.getData()
            },
            onRowSelect: () => {
            },
            mensaje(texto: string) {
                confirm(texto);
                local.value.reload(true);
            },
            back: () => {

                if (0 < local.value.pagina) {
                    local.value.pagina = local.value.pagina - 1
                    local.value.getData()
                }
            },
            paginar: (tamanoPagina: number) => {
                local.value.tamano = tamanoPagina;
                local.value.reload(true);
            },
            getValor: (opciones: any[], valor: any) => {
                let encontrado = opciones.find((elem) => {
                    return elem.valor == valor;
                })
                if (encontrado)
                    return encontrado.nombre;
                return valor;
            },
            guardarEditado: (event: DataTableRowEditCancelEvent) => {
                let { newData, index, field, data } = event;
                console.log('guardar', event);
                if (newData[field] == data[field])
                    return;
                local.value.guardando = true;
                local.value.save(newData);
                local.value.guardando = false;
                (local.value.data as Array<any>)[index] = newData;
            },
            accion: async (accionPersonalizada: (callback: (texto: string) => void, params: any) => any, params: any) => {
                local.value.cargandoAccion = true;
                local.value.loading = true;
                await accionPersonalizada(local.value.mensaje, params);
                local.value.loading = false;
                local.value.cargandoAccion = false;
                local.value.reload(true);
            },
            formatearFecha: (fecha: any, formato: string = 'DD/MM/YYYY') => {
                if (fecha) {
                    return moment(String(fecha)).format(formato);
                }
            },
            errorArchivo: (error: any) => {
                console.log(error)
                local.value.loading = false;
                let message = ('string' === typeof error?.xhr?.response) ? JSON.parse(error.xhr.response).mensaje || JSON.parse(error.xhr.response).message || 'No se pudo guardar' : 'No se pudo guardar'
                storeToast.add({
                    severity: 'error',
                    closable: true,
                    detail: message,
                    life: 5000
                })
            },
            okArchivo: (ok: any) => {
                console.log(ok);
                local.value.loading = false;
                local.value.modalMessage = ('string' === typeof ok?.xhr?.response) ? ok.xhr.response : 'No se pudo guardar'
                local.value.modal = true

                local.value.reload(true);
            },
            cargando: () => {
                local.value.loading = true;
            }
        });

        return {
            storeToast,
            local,
            storeLogin
        }

    },
    mounted() {
        console.log('mounted');
    },
    created() {
        console.log(this.local);
        if (this.local.globalCampo) {
            this.local.reload(true);
        } else
            this.local.getData();
        console.log('created');
    },
    updated() {
        console.log('updated');
        this.local.reload();
    },
    destroyed() {
        console.log('Destruido');
    },
    onMounted() {
        console.log('onMounted');
    },
    onUpdated() {
        console.log('onUpdated');
    }
})


</script>

<template>
    <ConfirmDialog></ConfirmDialog>
    <div>
        <div class="multipaso-wrapper">
            <div class="cabecera-pagina">
                <span class="titulo1 enfasis xxl bold primario-t uppercase">{{ data!.titulo }}</span>
            </div>
            <div class="contenido-pagina">
                <div class="buscador"></div>
                <div class="formulario-wrapper">
                    <main>
                        <div class="contenido-formulario">
                            <div id="contenido0" class="wrapper-cf" :class="'contenido0'">
                                <div v-if="local.globalCampo" class="el-dropdown">
                                    <label class=" texto   blanco-t s">{{ local.globalEtiqueta }}</label>
                                    <Dropdown class="dropdown-normal" v-model="local.globalValor"
                                        :options="local.globalOpciones" optionLabel="nombre" @change="local.getData"
                                        :virtual-scroller-options="{
                                            itemSize: 12
                                        }" optionValue="valor" placeholder="Seleccionar" :filter="true"
                                        filter-placeholder="Filtrar" />
                                </div>
                                <p></p>
                                <div class="cont-formulario gris-formulario-b">
                                    <div class="scroll-formulario">
                                        <div class="form-wrap">
                                            <DataTable class="data-show" :value="local.data" v-if="!local.loading"
                                                responsiveLayout="scroll" @row-select="local.onRowSelect()"
                                                v-model:selection="local.selectedRows" dataKey="id" edit-mode="cell"
                                                @cell-edit-complete="local.guardarEditado" filterDisplay="row"
                                                :scrollable="true" scrollHeight="calc(100vh - 130px)"
                                                scrollDirection="both">
                                                <Column v-if="data.selector" selection-mode="multiple"
                                                    header-style="width: 3em !important" style="width: 3em !important;">
                                                </Column>
                                                <Column v-for="(datos) in data!.campos" :field="datos.nombreCampo"
                                                    :frozen="datos.fijo">
                                                    <template #header>
                                                        <div class="titulo-tabla">
                                                            {{ datos.etiqueta }} <br>
                                                        </div>
                                                        <div class="filter-tabla" v-if="datos.filtro">
                                                            <div v-if="datos.tipoCampo === 'input text' || datos.tipoCampo === 'enlace'"
                                                                class="el-input">
                                                                <InputText class="input-normal texto s"
                                                                    v-model="datos.filterValue" autofocus
                                                                    @keyup.enter="local.getData" />
                                                            </div>
                                                            <div v-if="datos.tipoCampo === 'dropdown'"
                                                                class="el-dropdown">
                                                                <Dropdown class="dropdown-normal"
                                                                    v-model="datos.filterValue"
                                                                    :options="datos.opciones" optionLabel="nombre"
                                                                    optionValue="valor" placeholder="Seleccionar"
                                                                    @keyup.enter="local.getData"
                                                                    @change="local.getData" />
                                                            </div>
                                                            <div v-if="datos.tipoCampo === 'numero'" class="el-input">
                                                                <InputNumber v-model="datos.filterValue"
                                                                    :min="datos.minimo || Number.MIN_VALUE"
                                                                    :max="datos.maximo || Number.MAX_VALUE"
                                                                    :minFractionDigits="datos.minDigitos || 0"
                                                                    :maxFractionDigits="datos.maxDigitos || 0" autofocus
                                                                    @keyup.enter="local.getData"
                                                                    @change="local.getData" />
                                                            </div>
                                                            <div v-if="datos.tipoCampo === 'mascara'" class="el-input">
                                                                <InputText class="input-normal texto s"
                                                                    :mask="datos.formato" v-model="datos.filterValue"
                                                                    autofocus @keyup.enter="local.getData"
                                                                    @change="local.getData" />
                                                            </div>
                                                            <div v-if="datos.tipoCampo === 'fecha'">
                                                                <Calendar v-model="datos.filterValue"
                                                                    :manual-input="false"
                                                                    :view="datos.tipoFecha || 'date'"
                                                                    :dateFormat="datos.formato || 'dd/mm/yyyy'"
                                                                    @keyup.enter="local.getData"
                                                                    @date-select="local.getData" />
                                                            </div>
                                                            <i style="cursor:pointer" v-if="datos.filterValue"
                                                                @click="datos.filterValue = undefined; local.getData()"
                                                                class="pi pi-filter-slash"></i>
                                                        </div>
                                                    </template>
                                                    <template #body="rowData">
                                                        <div
                                                            v-if="rowData.data[datos.nombreCampo] != null && rowData.data[datos.nombreCampo] != undefined">
                                                            <div v-if="datos.opciones">
                                                                {{
                                                                    local.getValor(datos.opciones, (rowData as
                                                                        any).data[datos.nombreCampo])
                                                                }}
                                                            </div>
                                                            <div v-if="datos.tipoCampo == 'fecha'">
                                                                {{
                                                                    local.formatearFecha(rowData.data[datos.nombreCampo],
                                                                        datos.formatoVue || 'DD/MM/YYYY')
                                                                }}
                                                            </div>
                                                            <div v-if="datos.tipoCampo == 'enlace'">
                                                                <a :href="rowData.data[datos.nombreCampo]">Ver</a>
                                                            </div>
                                                            <div v-if="!datos.opciones && datos.tipoCampo != 'fecha'">
                                                                {{ rowData.data[datos.nombreCampo] }}
                                                            </div>
                                                        </div>
                                                        <div v-else>
                                                            <div v-if="data.valorNulo"><i style="font-size: .7em;">{{
                                                                data.valorNulo(rowData.data, datos.nombreCampo)
                                                            }}</i></div>
                                                            <span v-else>...</span>
                                                        </div>
                                                    </template>
                                                    <template #editor="rowData">
                                                        <div v-if="!local.guardando">
                                                            <div v-if="datos.deshabilitado || !data.editar">
                                                                <div
                                                                    v-if="rowData.data[datos.nombreCampo] != null && rowData.data[datos.nombreCampo] != undefined">
                                                                    <div v-if="datos.opciones">
                                                                        {{
                                                                            local.getValor(datos.opciones, (rowData as
                                                                                any).data[datos.nombreCampo])
                                                                        }}
                                                                    </div>
                                                                    <div v-if="datos.tipoCampo == 'fecha'">
                                                                        {{
                                                                            local.formatearFecha(rowData.data[datos.nombreCampo],
                                                                                datos.formatoVue || 'DD/MM/YYYY')
                                                                        }}
                                                                    </div>
                                                                    <div v-if="datos.tipoCampo == 'enlace'">
                                                                        <a
                                                                            :href="rowData.data[datos.nombreCampo]">Ver</a>
                                                                    </div>
                                                                    <div
                                                                        v-if="!datos.opciones && datos.tipoCampo != 'fecha'">
                                                                        {{ rowData.data[datos.nombreCampo] }}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div v-else>
                                                                <div v-if="datos.tipoCampo === 'input text' || datos.tipoCampo === 'input text'"
                                                                    class="el-input">
                                                                    <InputText class="input-normal texto s"
                                                                        v-model="rowData.data[rowData.field]"
                                                                        autofocus />
                                                                </div>
                                                                <div v-if="datos.tipoCampo === 'dropdown'"
                                                                    class="el-dropdown">
                                                                    <Dropdown class="dropdown-normal"
                                                                        v-model="rowData.data[rowData.field]"
                                                                        :options="datos.opciones" optionLabel="nombre"
                                                                        optionValue="valor" placeholder="Seleccionar" />
                                                                </div>
                                                                <div v-if="datos.tipoCampo === 'numero'"
                                                                    class="el-input">
                                                                    <InputNumber v-model="rowData.data[rowData.field]"
                                                                        :min="datos.minimo || Number.MIN_VALUE"
                                                                        :max="datos.maximo || Number.MAX_VALUE"
                                                                        :minFractionDigits="datos.minDigitos || 0"
                                                                        :maxFractionDigits="datos.maxDigitos || 0"
                                                                        autofocus />
                                                                </div>
                                                                <div v-if="datos.tipoCampo === 'mascara'"
                                                                    class="el-input">
                                                                    <InputText class="input-normal texto s"
                                                                        v-model="rowData.data[rowData.field]"
                                                                        :mask="datos.formato" autofocus />
                                                                </div>
                                                                <div v-if="datos.tipoCampo === 'fecha'">
                                                                    <Calendar v-model="rowData.data[rowData.field]"
                                                                        :manual-input="false"
                                                                        :view="datos.tipoFecha || 'date'"
                                                                        :dateFormat="datos.formato || 'dd/mm/yyyy'" />
                                                                </div>
                                                                <div v-if="datos.tipoCampo === 'listado'"
                                                                    class="el-input">
                                                                    <div v-if="datos.listado">
                                                                        Valores permitidos: <template
                                                                            v-for="opcion in datos.opciones"> {{
                                                                                opcion
                                                                            }} </template>
                                                                    </div>
                                                                    <Chips v-model="rowData.data[rowData.field]"
                                                                        separator=","></Chips>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div v-else class="loading-screen">
                                                            <Presence>
                                                                <Motion class="cargando-wrapper" v-if="local.loading"
                                                                    :initial="{ opacity: 0, translateY: '50px' }"
                                                                    :animate="{ opacity: 1, translateY: 0 }" :transition="{
                                                                        duration: .6,
                                                                        easing: 'cubic-bezier(0.175, 0.885, 0.320, 1.275)'
                                                                    }">
                                                                    <i
                                                                        class="fa-solid fa-circle-notch xl primario-t fa-spin"></i>
                                                                    <span class="blanco-t enfasis l">Guardando
                                                                        ...</span>
                                                                </Motion>
                                                            </Presence>
                                                        </div>
                                                    </template>
                                                </Column>
                                            </DataTable>
                                            <div v-if="local.loading" class="loading-screen">
                                                <Presence>
                                                    <Motion class="cargando-wrapper" v-if="local.loading"
                                                        :initial="{ opacity: 0, translateY: '50px' }"
                                                        :animate="{ opacity: 1, translateY: 0 }" :transition="{
                                                            duration: .6,
                                                            easing: 'cubic-bezier(0.175, 0.885, 0.320, 1.275)'
                                                        }">
                                                        <span class="blanco-t enfasis l">Un momento por favor</span>
                                                        <i class="fa-solid fa-circle-notch xl primario-t fa-spin"></i>
                                                    </Motion>
                                                </Presence>
                                            </div>
                                            <div>
                                                Viendo: {{ (local.pagina * local.tamano) + 1 }} - 
                                                <span v-if="(local.pagina + 1) * local.tamano < local.total" >{{ (local.pagina + 1)
                                                * local.tamano }}</span>
                                                <span v-else>{{ local.total }}</span>
                                                 Registros: {{ local.total }}.
                                                Ver:
                                                <button class="boton anima enfasis primario-b negro-t s bold"
                                                    style="--color: var(--primario); --texto:var(--negro); display: inline !important"
                                                    v-on:click="local.paginar(20)">20</button>,
                                                <button class="boton anima enfasis primario-b negro-t s bold"
                                                    style="--color: var(--primario); --texto:var(--negro); display: inline !important"
                                                    v-on:click="local.paginar(50)">50</button>,
                                                <button class="boton anima enfasis primario-b negro-t s bold"
                                                    style="--color: var(--primario); --texto:var(--negro); display: inline !important"
                                                    v-on:click="local.paginar(100)">100</button>.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="botonera">
                            <div class="masivo" v-if="local.selectedRows && local.selectedRows.length">
                                <button v-for="accion in local.masivo"
                                    class="boton anima enfasis primario-b negro-t s bold"
                                    style="--color: var(--primario); --texto:var(--negro)"
                                    v-on:click="local.guardarMasivo(local.selectedRows, (accion as any).campo, (accion as any).valor, (accion as any).campoObservacion, (accion as any).textoObservacion, (accion as any).validacion)">{{
                                    (accion as any).titulo }}</button>
                            </div>
                            <button class="boton anima enfasis primario-b negro-t s bold"
                                style="--color: var(--primario); --texto:var(--negro)" v-on:click="local.back()"><i
                                    class="fas fa-chevron-circle-left m"></i></button>
                            <button class="boton anima enfasis primario-b negro-t s bold"
                                style="--color: var(--primario); --texto:var(--negro)" v-on:click="local.getData()"><i
                                    class="fas fa-rotate m"></i></button>
                            <button class="boton anima enfasis primario-b negro-t s bold"
                                style="--color: var(--primario); --texto:var(--negro)" v-on:click="local.next()"><i
                                    class="fas fa-chevron-circle-right m"></i></button>
                            <button class="boton anima enfasis primario-b negro-t s bold" v-if="data.agregar"
                                style="--color: var(--primario); --texto:var(--negro)"
                                v-on:click="local.agregarForm()"><i class="fas fa-save m"></i>
                                Agregar </button>
                            <template v-for="accion in local.acciones">
                                <template v-if="storeLogin.existeRol((accion as any).rol || '')">

                                    <FileUpload v-if="(accion as any).urlUpload"
                                    class="boton anima enfasis primario-b negro-t s bold" mode="basic" :auto="true"
                                    :url="(accion as any).urlUpload" v-on:upload="local.okArchivo"
                                    :maxFileSize="10000000" :disabled="local.cargandoAccion"
                                    :choose-label="(accion as any).titulo" v-on:error="local.errorArchivo" name="file"
                                    @before-upload="local.cargando"></FileUpload>
                                    <button v-else class="boton anima enfasis primario-b negro-t s bold"
                                    :disabled="local.cargandoAccion"
                                    style="--color: var(--primario); --texto:var(--negro)"
                                    v-on:click="local.accion((accion as any).accion, local.globalValor)"><i
                                        v-if="(accion as any).icono" :class="'fas ' + (accion as any).icono + ' m'"></i>
                                        {{ (accion as any).titulo }} </button>
                                </template>
                            </template>
                        </div>
                    </main>
                </div>
            </div>
        </div>
        <Dialog v-model:visible="local.modal" :modal="true" class="recover-modal" :dismissableMask="true"
            @hide="!local.modal">
            <pre>
                {{ local.modalMessage }}
            </pre>
        </Dialog>
        <Dialog v-model:visible="local.agregar" :modal="true" class="recover-modal" :dismissableMask="true"
            @hide="!local.agregar">
            <template #header>
                <span class="enfasis uppercase primario-t bold l">Agregar</span>
            </template>
            <form @submit.prevent class="recover-pass">

                <template v-for="(datos) in data!.campos">
                    <template v-if="datos.crear">
                        <div class="elemento-formulario"
                            :style="{ 'min-width': (60 + ((datos.etiqueta?.length || 0) > (datos.valor?.length || 0) ? (datos.etiqueta?.length || 0) : (datos.valor?.length || 0)) * 7) + 'px', 'max-width': datos.tipoCampo === 'select button' ? '180px ' : '' }">
                            <div v-if="datos.tipoCampo === 'input text' || datos.tipoCampo == 'fecha'" class="el-input">

                                <label class=" texto etiqueta-input  blanco-t s"
                                    :class="{ 'titulo-etiqueta-requerido': datos.requerido }">{{
                                        datos.etiqueta
                                    }}</label>
                                <i :class="'icono-input ' + datos.icono"></i>
                                <InputText class="input-normal texto s" :class="{ 'with-icon': datos.icono }"
                                    type="text" :placeholder="datos.placeholder" :disabled='datos.disabled'
                                    :id="datos.nombreCampo" v-tooltip.top.focus="datos.mensaje_info"
                                    v-model="local.selectedRow[datos.nombreCampo]" />
                                <small :class="{ 'p-error': datos.error }" class="texto s">{{
                                    datos.mensaje_error
                                }}</small>

                            </div>
                            <div v-if="datos.tipoCampo === 'mascara'" class="el-input">

                                <label class=" texto etiqueta-input  blanco-t s"
                                    :class="{ 'titulo-etiqueta-requerido': datos.requerido }">{{
                                        datos.etiqueta
                                    }}</label>
                                <i :class="'icono-input ' + datos.icono"></i>
                                <InputText class="input-normal texto s" :mask="datos.formato"
                                    :class="{ 'with-icon': datos.icono }" type="text" :placeholder="datos.placeholder"
                                    :disabled='datos.disabled' :id="datos.nombreCampo"
                                    v-tooltip.top.focus="datos.mensaje_info"
                                    v-model="local.selectedRow[datos.nombreCampo]" />
                                <small :class="{ 'p-error': datos.error }" class="texto s">{{
                                    datos.mensaje_error
                                }}</small>

                            </div>
                            <div v-if="datos.tipoCampo === 'numero'" class="el-input">
                                <label class=" texto etiqueta-input  blanco-t s"
                                    :class="{ 'titulo-etiqueta-requerido': datos.requerido }">{{
                                        datos.etiqueta
                                    }}</label>
                                <i :class="'icono-input ' + datos.icono"></i>
                                <InputNumber class="input-normal texto s" :min="datos.minimo || Number.MIN_VALUE"
                                    :max="datos.maximo || Number.MAX_VALUE" :minFractionDigits="datos.minDigitos || 0"
                                    :maxFractionDigits="datos.maxDigitos || 0" :class="{ 'with-icon': datos.icono }"
                                    :id="datos.nombreCampo" type="text" :placeholder="datos.placeholder"
                                    :disabled='datos.disabled' v-tooltip.top.focus="datos.mensaje_info"
                                    v-model="local.selectedRow[datos.nombreCampo]" />
                                <small :class="{ 'p-error': datos.error }" class="texto s">{{
                                    datos.mensaje_error
                                }}</small>

                            </div>
                            <div v-if="datos.tipoCampo === 'dropdown'" class="el-dropdown">
                                <label class=" texto   blanco-t s"
                                    :class="{ 'titulo-etiqueta-requerido': datos.requerido }">{{
                                        datos.etiqueta
                                    }}</label>
                                <Dropdown class="dropdown-normal" v-model="local.selectedRow[datos.nombreCampo]"
                                    :options="datos.opciones" optionLabel="nombre" :id="datos.nombreCampo"
                                    optionValue="valor" placeholder="Seleccionar" />
                                <small :class="{ 'p-error': datos.error }" class="texto s">{{
                                    datos.mensaje_error
                                }}</small>
                            </div>
                            <div v-if="datos.tipoCampo === 'select button'" class="el-select">
                                <label class=" texto blanco-t s"
                                    :class="{ 'titulo-etiqueta-requerido': datos.requerido }">{{
                                        datos.etiqueta
                                    }}</label>
                                <SelectButton v-model="local.selectedRow[datos.nombreCampo]" :options="datos.opciones"
                                    :id="datos.nombreCampo" optionLabel="nombre" dataKey="valor" />
                                <small :class="{ 'p-error': datos.error }" class="texto s">{{
                                    datos.mensaje_error
                                }}</small>
                            </div>
                            <div v-if="datos.tipoCampo === 'upload'" class="el-upload">
                                <label class=" texto   blanco-t s"
                                    :class="{ 'titulo-etiqueta-requerido': datos.requerido }">{{
                                        datos.etiqueta
                                    }}</label>
                                <FileUpload mode="basic" name="demo[]" url="./upload" :id="datos.nombreCampo"
                                    @upload="storeToast.add({ summary: 'Subir archivo', detail: 'el archivo se subio con exito' })"
                                    :auto="true" chooseLabel="Escoger" />
                                <small :class="{ 'p-error': datos.error }" class="texto s">{{
                                    datos.mensaje_error
                                }}</small>
                            </div>
                            <div v-if="datos.tipoCampo === 'switch'" class="el-switch">
                                <div class="obj-switch" v-for="s in datos.lista">
                                    <label class=" texto   blanco-t s"
                                        :class="{ 'titulo-etiqueta-requerido': s.requerido }">{{
                                            s.etiqueta
                                        }}</label>
                                    <InputSwitch v-model="s.checked" class="input-switch" :id="datos.nombreCampo" />
                                    <small :class="{ 'p-error': s.error }" class="texto s">{{
                                        s.mensaje_error
                                    }}</small>
                                </div>
                            </div>
                            <div v-if="datos.tipoCampo === 'label'" class="el-label">
                                <label class=" texto grupo-formulario-t s"
                                    :class="{ 'titulo-etiqueta-requerido': datos.requerido }">{{
                                        datos.etiqueta
                                    }}</label>
                                <span class="label-form texto gris-oscuro-t m "><i :class="datos.icono"></i>
                                    <p class="texto s">{{ datos.valor }}</p>
                                </span>
                            </div>
                            <div v-if="datos.tipoCampo === 'listado'" class="el-input">
                                <label class=" texto grupo-formulario-t s"
                                    :class="{ 'titulo-etiqueta-requerido': datos.requerido }">
                                    {{ datos.etiqueta }}
                                </label>
                                <div v-if="datos.listado">
                                    Valores permitidos: <template v-for="opcion in datos.lista"> {{ opcion }}
                                    </template>
                                </div>
                                <Chips v-model="local.selectedRow[datos.nombreCampo]" :id="datos.nombreCampo"
                                    separator=","></Chips>
                            </div>
                        </div>
                    </template>
                </template>
                <div class="boton-guardar">
                    <button class="boton enfasis negro-t primario-b anima s bold"
                        style="--color: var(--primario); --texto:var(--negro)"
                        v-on:click="local.save(local.selectedRow, true)">Guardar</button>
                </div>
            </form>
        </Dialog>
    </div>
</template>
