<script setup lang="ts">
import { useLoginStore } from '@/store/login';
import Dropdown from 'primevue/dropdown';
import axios from 'axios';
import { ref, onMounted } from 'vue';

const loginStore = useLoginStore();
loginStore.getUser();

let link = 'http://localhost:8080';
if (location.href.indexOf('localhost') < 0)
    link = `${location.protocol}//${location.hostname}:8082`

let url = loginStore.link + '/scap/inventario'
const todoInventario = loginStore.link + '/scap/inventario/matriz-subestacion/inventario'
let fecha = ref('')
let fechas = ref([])
let nivel = ref('')
let tipoArchivo = ref('')

const arcgis = () => {
    window.open(`${url}/matriz-subestacion/arcgis?alcance=${fecha.value}`);
}
const sap = () => {
    window.open(`${url}/matriz-subestacion/sap?alcance=${fecha.value}`);
}
const todo = () => {
    let alcance = fecha.value ? `&alcance=${fecha.value}` : '';
    let nivelTension = nivel.value ? `&nivelTension=${nivel.value}` : '';
    let tipo = tipoArchivo.value ? `&tipo=${tipoArchivo.value}` : '';
    window.open(`${url}/matriz-subestacion/inventario?x=1${alcance}${nivelTension}${tipo}`);
}
const getFechas = () => {
    axios.get(url + '/matriz-subestacion/global').then(data => {
        fechas.value = data.data
    });
}


onMounted(() => {
    getFechas();
})
</script>
<template>
    <div>
        <div class="multipaso-wrapper">
            <div class="cabecera-pagina">
                <span class="titulo1 enfasis xxl bold primario-t uppercase">Descarga historial Generación</span>
            </div>
            <div class="contenido-pagina">
                <div class="formulario-wrapper">
                    <main>
                        <div class="contenido-formulario">
                            <div id="contenido0" class="wrapper-cf" :class="'contenido0'">
                                <div class="cont-formulario gris-formulario-b">
                                    <div class="scroll-formulario">
                                        <div class="form-wrap">
                                            <div>
                                                <div class="ctrl-descarga">
                                                    Alcance a descargar
                                                    <InputText placeholder="Alcance clic-botoones" class="input-normal texto s" v-model="fecha" disabled />
                                                    <InputText placeholder="Nivel de tensión" class="input-normal texto s" v-model="nivel" />
                                                    <Dropdown v-model="tipoArchivo" :options="['','SUBESTACIONES', 'LINEAS_DISTRI', 'TRAFOS_DISTRI', 'LIENAS']" />
                                                    <button class="boton anima enfasis primario-b negro-t s bold"
                                                    style="--color: var(--primario); --texto:var(--negro)" v-on:click="todo()"><i
                                                    class="fas fa-save m"></i>
                                                    Descargar </button>
                                                    <a class="boton anima enfasis primario-b negro-t s bold" style="float: right" :href="todoInventario" target="_blank">Descargar toda la historia</a>
                                                </div>
                                                <br>
                                                Histórico de Alcances:
                                                <br>
                                                <div v-for="item in fechas">
                                                    <button class="boton anima enfasis primario-b negro-t s bold"
                                                        @click="fecha = item">{{ item }}</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
</div>
</template>
<style>
.ctrl-descarga {
    display: flex;
    flex-direction: row;
}
.ctrl-descarga > * {
    margin: .5em;
}
</style>