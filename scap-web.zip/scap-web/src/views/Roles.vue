<script setup lang="ts">

import axios from 'axios';
import { useToast } from 'primevue/usetoast';
import { onMounted, ref } from 'vue';
import { useLoginStore } from '../store/login'

import Listbox from 'primevue/listbox';
import Checkbox from 'primevue/checkbox';
import { TODOS } from '@/interfaces';



const loginStore = useLoginStore();
const storeToast = useToast()

const roleData = ref({
    prvilegeList: TODOS,
    selectedRole: undefined as any,
    selectedPrivileges: [] as any,
    roles: [] as any,
    linkRoles: loginStore.link + '/scap/inventario/scap-role',
    rolNuevo: ''
});

const crearRole = () => {
    guardarRole({
        nombre: roleData.value.rolNuevo
    });
    roleData.value.rolNuevo = '';
}

const guardarRole = (role: any) => {
    let m = {...role}
    if(Array.isArray(m.privilegio))
        m.privilegio = m.privilegio.join(',')
    axios.post(roleData.value.linkRoles, m).then(ok => {
        roleData.value.selectedRole = ok.data
        downloadRole()
    }).catch(error => {
        console.error(error)
        storeToast.add({
            closable: true,
            detail: 'No se pudo Guardar el Rol',
            life: 2000,
            summary: 'Error al guardar'
        })
    })
}

const downloadRole = () => {
    axios.get(roleData.value.linkRoles).then((val => {
        if(!Array.isArray(val.data))
            return;
            let roles = []
        roleData.value.roles = [];
        for(let v of val.data) {
            if('string' == typeof v.privilegio) {
                v.privilegio = v.privilegio.split(',')
            }
            roles.push(v)
        }
        roleData.value.roles = roles;
        roleData.value.selectedRole = undefined
    })).catch(error => {
        storeToast.add({
            closable: true,
            detail: 'No se pudo descargar Roles',
            life: 2000,
            summary: 'Error descagando Roles'
        })
    })
}

onMounted(() => {
    downloadRole();
})

</script>
<template>
    <div class="multipaso-wrapper">
        <div class="cabecera-pagina"><span class="titulo1 enfasis xxl bold primario-t uppercase">
                Gestión de roles de scap
            </span>

        </div>
        <div class="contenido-pagina">
            <div class="formulario-wrapper">
                <main>
                    <div class="contenido-formulario">
                        <div id="contenido0" class="wrapper-cf" :class="'contenido0'">
                            <div class="cont-formulario gris-formulario-b">
                                <div class="scroll-formulario">
                                    <div class="form-wrap">
                                        <div>
                                            <div>
                                                <h1>Roles</h1>
                                            </div>
                                            <div class="flex">
                                                <div class="flex-item">
                                                    <label>Nuevo Rol</label>
                                                    <div>
                                                        <InputText class="input-normal texto s"
                                                            v-model="roleData.rolNuevo" autofocus
                                                            @keyup.enter="crearRole" />
                                                    </div>
                                                </div>
                                                <div class="flex-item" style="max-height: 50vh; overflow: scroll;">
                                                    Roles del Sistema
                                                    <Listbox :options="roleData.roles" v-model="roleData.selectedRole"
                                                        option-label="nombre"></Listbox>
                                                </div>
                                                <div v-if="roleData.selectedRole" class="flex-item"
                                                    style="max-height: 50vh; overflow: scroll;">
                                                    Privilegios del Rol
                                                    <div v-for="item in roleData.prvilegeList">
                                                        <Checkbox name="privilegio" :value="item"
                                                            v-model="(roleData.selectedRole as any).privilegio" /> {{
                                                                item
                                                            }}
                                                    </div>
                                                    <button class="boton anima enfasis primario-b negro-t s bold"
                                                        style="--color: var(--primario); --texto:var(--negro)"
                                                        v-on:click="guardarRole(roleData.selectedRole)"><i
                                                            class="fas fa-check m"></i>Guardar</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>
</template>