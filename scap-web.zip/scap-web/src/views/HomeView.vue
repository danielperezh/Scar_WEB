<script setup lang="ts">

import { useLoginStore } from '@/store/login';
import Avatar from '../components/sidebar/Avatar.vue'
import Menu from '../components/sidebar/Menu.vue'

const useLogin = useLoginStore();
useLogin.getUser();
</script>

<template>
  <div>

    <div class="container">
      <aside v-if="useLogin.userlogin.authenticated" id="sidebar">
          <Avatar />
          <Menu />
      </aside>
      <main class="main degradado" id="main">
        <router-view class="paginas"></router-view>
        <div class="bg-img"></div>
      </main>
      <div class="logo"><img src="../assets/logo.svg" alt=""></div>
    </div>
  </div>
</template>