<script setup lang="ts">
import '../css/formulario.css'
import '../css/toast.css'
import { useLoginStore } from '@/store/login';
import { onMounted, ref } from 'vue';
import Dropdown from 'primevue/dropdown';
import DataTable from 'primevue/datatable';
import axios from 'axios';
import { useToast } from 'primevue/usetoast';
import type Column from 'primevue/column';


const loginStore = useLoginStore();
loginStore.getUser();
const storeToast = useToast()

const cargando = ref(false);
const formato = ref({} as any);
const tipo = ref({} as any);
const opciones = ref([] as any[])
const ejecuciones = ref([] as any)
let tipos = ref([
    { label: 'INVA', value: 'V' },
    { label: 'INVTR', value: 'R' },
    { label: 'BRA', value: 'B' },
    { label: 'BRAFO', value: 'F' },
] as any);

let link = 'http://localhost:8080';
if (location.href.indexOf('localhost') < 0)
link = `${location.protocol}//${location.hostname}:8082`
let linkFormato = `${link}/scap/formato`

const getFormatos = () => {
    if(!tipo.value) return;
    const url = `${linkFormato}/formatos?tipo=${tipo.value}`
    axios.post(url).then(res => {
        opciones.value = res.data
        console.log('opciones', opciones.value)
    }).catch(error => {
        storeToast.add({ severity: 'error', summary: 'Error al cargar formatos', detail: error.message, life: 3000, closable: true });
    })
}

const getData = () => {
    cargando.value = true;
    const url = `${linkFormato}/ejecuciones/${formato.value}`
    axios.post(url).then(res => {
        ejecuciones.value = res.data
        cargando.value = false;
    }).catch(error => {
        storeToast.add({ severity: 'error', summary: 'Error al cargar formatos', detail: error.response?.data?.message || error.response?.data?.error || error.message, life: 3000, closable: true });
        cargando.value = false;
    })
}

const agregar = () => {
    let nombre = prompt("Ingrese el nombre de la ejecución")
    let url = `${linkFormato}/crear/${formato.value}/${nombre}`
    axios.post(url).then(res => {
        storeToast.add({ severity: 'success', summary: 'Ejecución creada', detail: 'La ejecución se ha creado correctamente', life: 3000, closable: true });
        getData()
    }).catch(error => {
        console.log(error)
        storeToast.add({ severity: 'error', summary: 'Error al crear ejecución', detail: error.response?.data?.message || error.response?.data?.error || error.message, life: 3000, closable: true });
    })
}

const confirmar = (ejecucionFormato: any) => {
    let url = `${linkFormato}/${ejecucionFormato.id}/confirmar`
    cargando.value = true;
    axios.post(url).then(res => {
        storeToast.add({ severity: 'success', summary: 'Ejecución confirmada', detail: 'La ejecución se ha confirmado correctamente', life: 3000, closable: true });
        cargando.value = false;
        getData()
    }).catch(error => {
        storeToast.add({ severity: 'error', summary: 'Error al confirmar ejecución', detail: error.response?.data?.message || error.response?.data?.error || error.message, life: 3000, closable: true });
        cargando.value = false;
    })
}

const ejecutar = (ejecucionFormato: any) => {
    let url = `${linkFormato}/${ejecucionFormato.id}/ejecutar`
    cargando.value = true;
    axios.post(url).then(res => {
        storeToast.add({ severity: 'success', summary: 'Ejecución Realizada', detail: 'La ejecución se ha realizado correctamente', life: 3000, closable: true });
        cargando.value = false;
    }).catch(error => {
        storeToast.add({ severity: 'error', summary: 'Error al ejecutar', detail: error.response?.data?.message || error.response?.data?.error || error.message, life: 3000, closable: true });
        cargando.value = false;
    })
}

const exportar = (ejecucionFormato: any) => {
    let url = `${linkFormato}/${ejecucionFormato.id}/exportar`
    window.open(url, '_blank');
}

const reporte = (tipo: string) => {
    let url = `${linkFormato}/exportar/reporte?tipo=${tipo}`
    window.open(url, '_blank');
}

</script>
<template>
    <div>
        <div class="multipaso-wrapper">
            <div class="cabecera-pagina">
                <span class="titulo1 enfasis xxl bold primario-t uppercase">Ejecución de formatos</span>
            </div>
            <div class="contenido-pagina">
                <div class="buscador"></div>
                <div class="formulario-wrapper">
                    <main>
                        <div class="contenido-formulario">
                            <div id="contenido0" class="wrapper-cf contenido0">
                                <Dropdown :disabled="cargando" class="dropdown-normal" v-model="tipo"
                                    :options="tipos" optionLabel="label" optionValue="value" placeholder="Escoger tipo"
                                    @change="getFormatos" ></Dropdown>
                                <Dropdown :disabled="cargando" v-if="opciones && opciones.length" class="dropdown-normal" v-model="formato"
                                        :options="opciones" optionLabel="nombre" @change="getData"
                                        optionValue="id" placeholder="Seleccionar Formato" />
                                <p></p>
                                <div class="cont-formulario gris-formulario-b">
                                        <div class="scroll-formulario">
                                            <div class="form-wrap">
                                                <DataTable class="data-show" :value="ejecuciones" >
                                                    <Column field="descripcion" header="Descripción"></Column>
                                                    <Column field="estado" header="Estado">
                                                        <template #body="rowData">
                                                            <span v-if="(rowData as any).data.estado == 'P'">Pendiente</span>
                                                            <span v-else-if="(rowData as any).data.estado == 'C'">Confirmado</span>
                                                            <span v-else>{{ (rowData as any).data.estado }}</span>
                                                        </template>
                                                    </Column>
                                                    <Column header="Acciones">
                                                        <template #body="rowData">
                                                            <div v-if="(rowData as any).data.estado == 'P'" >
                                                                <button :disabled="cargando" class="boton anima enfasis primario-b negro-t s bold" v-on:click="confirmar(rowData.data)" > Confirmar</button>
                                                                <button :disabled="cargando" class="boton anima enfasis primario-b negro-t s bold" v-on:click="ejecutar(rowData.data)" > Ejecutar</button>
                                                            </div>
                                                            <button :disabled="cargando" class="boton anima enfasis primario-b negro-t s bold" v-on:click="exportar(rowData.data)" > Exportar</button>
                                                        </template>
                                                    </Column>
                                                </DataTable>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                        <div class="botonera">
                            <div class="masivo">
                                <button class="boton anima enfasis primario-b negro-t s bold"
                                    style="--color: var(--primario); --texto:var(--negro)"  v-on:click="reporte('V')"><i
                                        class="fas fa-file m"></i> Formato Variables</button>
                                <button class="boton anima enfasis primario-b negro-t s bold"
                                    style="--color: var(--primario); --texto:var(--negro)"  v-on:click="reporte('E')"><i
                                        class="fas fa-file m"></i> Formato Ejecucion</button>
                            </div>
                            <button class="boton anima enfasis primario-b negro-t s bold"
                                style="--color: var(--primario); --texto:var(--negro)"  v-on:click="agregar"><i
                                    class="fas fa-save m"></i> Agregar</button>
                            
                        </div>
                    </main>
                </div>
            </div>
        </div>
    </div>
</template>