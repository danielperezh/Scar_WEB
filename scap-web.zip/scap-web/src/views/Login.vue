<template>
  <div class="login-wrapper degradado">
    <div class="login-box" :initial="{ opacity: 0, scale: .8 }"
      :animate="{ opacity: 1, scale: 1, transition: { duration: .7, easing: 'cubic-bezier(0.175, 0.885, 0.320, 1.275)', delay: 1 } }">
      <div>
        <div v-if="!loading" class="login-screen" :animate="{ opacity: 1, scale: 1 }" :exit="{ opacity: 0, scale: .9 }">
          <span class="titulo enfasis blanco-t xxl bold">Iniciar sesion</span>
          <span class="blanco-t texto m normal texto-login">Bienvenido nuevamente, ingresa los datos para acceder al
            sistema.</span>
          <Form @submit="handleLogin" :validation-schema="schema">
            <div class="login-form ">
              <div class="elemento">
                <label for="username" class="enfasis blanco-t s uppercase">Usuario:</label>
                <Field name="username" type="text" class="input-normal texto s form-control"
                  placeholder="alguien@ejemplo.com" />
              </div>
              <div class="elemento">
                <label for="password" class="enfasis blanco-t s uppercase">Contraseña:</label>
                <Field name="password" type="password" class="input-normal texto s form-control" placeholder="****" />
              </div>
            </div>
            <div class="footer-login" style="padding-top: 10px">
              <span class="texto primario-t subrayado-primario cursor-pointer s"></span>
              <button class="boton primario-b negro-t s enfasis bold anima"
                style="--color: var(--primario); --texto:var(--negro)">Iniciar sesion</button>
            </div>
          </Form>
        </div>

        <div v-if="loading" class="loading-screen">
          <Presence>
            <Motion class="cargando-wrapper" v-if="loading" :initial="{ opacity: 0, translateY: '50px' }"
              :animate="{ opacity: 1, translateY: 0 }" :transition="{
                duration: .6,
                easing: 'cubic-bezier(0.175, 0.885, 0.320, 1.275)'
              }">
              <span class="blanco-t enfasis l">Un momento por favor</span>
              <i class="fa-solid fa-circle-notch xl primario-t fa-spin"></i>
            </Motion>
          </Presence>
        </div>
      </div>
      <div v-if="message" class="alert blanco-t alert-danger" role="alert">
        {{ message }}
      </div>
    </div>
  </div>
</template>

<script setup  lang="ts">
import { Form, Field } from "vee-validate";
import * as yup from "yup";
import "../css/login.css";

import { useLoginStore } from '@/store/login';
import axios from "axios";
import router from "@/router";
import { ref, onMounted } from "vue";


const message = ref('')
const loading = ref(false);
const loginStore = useLoginStore();
const schema = yup.object().shape({
  username: yup.string().required("Username is required!"),
  password: yup.string().required("Password is required!"),
});

const handleLogin = (user: any) => {
  loading.value = true;

  axios.post(`${loginStore.link}/auth/signin`, user).then(
    (data) => {
      loading.value = false;
      loginStore.setUser(data.data);
      if (loginStore.userlogin.authenticated)
        router.push("/");
      else message.value = 'No se puede iniciar sesión';
    }).catch(
      (error) => {
        loading.value = false;
        message.value =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
      }
    );
}

onMounted(() => {
  loginStore.logout();
})
</script>
