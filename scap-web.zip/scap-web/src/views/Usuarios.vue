<script setup lang="ts">

import axios from 'axios';
import { useToast } from 'primevue/usetoast';
import { onMounted, ref } from 'vue';
import { useLoginStore } from '../store/login'

import Listbox from 'primevue/listbox';
import Checkbox from 'primevue/checkbox';

const loginStore = useLoginStore();
const storeToast = useToast()

const userData = ref({
    roleList: [] as any,
    selectedUsuario: undefined as any,
    selectedUsuarios: [] as any,
    usuarios: [] as any,
    linkRoles: loginStore.link + '/scap/inventario/scap-role',
    linkUsers: loginStore.link + '/scap/inventario/usuario',
    usuarioNuevo: ''
});

const crearUsuario = () => {
    axios.post(`${userData.value.linkUsers}/nuevo/${userData.value.usuarioNuevo}`).then(ok =>{
        storeToast.add({
            closable: true,
            detail: 'Creado',
            life: 2000,
            summary: 'Correctamente'
        })
        downloadUsuario()
    }).catch(error =>{
        console.error(error);
        storeToast.add({
            closable: true,
            detail: 'No se pudo crear el usuario',
            life: 2000,
            summary: 'Error al crear el usuario'
        })
        downloadUsuario()
    })
    userData.value.usuarioNuevo = '';
}

const guardarUsuario = (usuario: any) => {
    axios.post(userData.value.linkUsers+"/guardar", usuario).then(ok => {
        userData.value.selectedUsuario = ok.data
        downloadUsuario()
    }).catch(error => {
        console.error(error)
        downloadUsuario()
    })
}

const cambiarContrasena = (usuario: any) => {
    usuario.contrasena = prompt(`Por favor ingrese la nueva contraseña para el usuario: ${usuario.usuario}`);
    guardarUsuario(usuario);
}

const eliminar = (usuario: any) => {
    let resp = confirm(`¿Está seguro que desea eliminar el usuario: ${usuario.usuario}?`);
    if(!resp)
        return;
    axios.post(`${userData.value.linkUsers}/eliminar?id=${usuario.id}`).then(ok => {
        storeToast.add({
            closable: true,
            detail: 'Eliminado',
            life: 2000,
            summary: 'Correctamente'
        })
        downloadUsuario()
    }).catch(error => {
        console.error(error);
        storeToast.add({
            closable: true,
            detail: 'No se pudo eliminar el usuario',
            life: 2000,
            summary: 'Error al eliminar el usuario'
        })
        downloadUsuario()
    })
}

const downloadUsuario = () => {
    axios.get(userData.value.linkUsers).then((val => {
        userData.value.usuarios = val.data;
        userData.value.selectedUsuario = undefined
    })).catch(error => {
        storeToast.add({
            closable: true,
            detail: 'No se pudo descargar Usuarios',
            life: 2000,
            summary: 'Error descagando Usuarios'
        })
    })
}

const downloadRoles = () => {
    axios.get(userData.value.linkRoles).then((val => {
        if(!Array.isArray(val.data))
            return;
            let roles = []
        userData.value.roleList = [];
        for(let v of val.data) {
            roles.push(v.nombre)
        }
        userData.value.roleList = roles;
    })).catch(error => {
        storeToast.add({
            closable: true,
            detail: 'No se pudo descargar Roles',
            life: 2000,
            summary: 'Error descagando Roles'
        })
    })
}

onMounted(() => {
    downloadRoles();
    downloadUsuario();
})

</script>
<template>
    <div class="multipaso-wrapper">
        <div class="cabecera-pagina"><span class="titulo1 enfasis xxl bold primario-t uppercase">
                Gestión de Usuarios de scap
            </span>

        </div>
        <div class="contenido-pagina">
            <div class="formulario-wrapper">
                <main>
                    <div class="contenido-formulario">
                        <div id="contenido0" class="wrapper-cf" :class="'contenido0'">
                            <div class="cont-formulario gris-formulario-b">
                                <div class="scroll-formulario">
                                    <div class="form-wrap">
                                        <div>
                                            <div>
                                                <h1>Usuarios</h1>
                                            </div>
                                            <div class="flex">
                                                <div class="flex-item">
                                                    <label>Nuevo usuario</label>
                                                    <div>
                                                        <InputText class="input-normal texto s"
                                                            v-model="userData.usuarioNuevo" autofocus
                                                            @keyup.enter="crearUsuario" />
                                                    </div>
                                                </div>
                                                <div class="flex-item" style="max-height: 50vh; overflow: scroll;">
                                                    Usuarios del Sistema
                                                    <Listbox :options="userData.usuarios" v-model="userData.selectedUsuario"
                                                        option-label="usuario"></Listbox>
                                                </div>
                                                <div v-if="userData.selectedUsuario" class="flex-item"
                                                    style="max-height: 50vh; overflow: scroll;">
                                                    Roles del usuario
                                                    <div v-for="item in userData.roleList">
                                                        <Checkbox name="roles" :value="item"
                                                            v-model="(userData.selectedUsuario as any).scapRoles" /> {{
                                                                item
                                                            }}
                                                    </div>
                                                    <button class="boton anima enfasis primario-b negro-t s bold"
                                                        style="--color: var(--primario); --texto:var(--negro)"
                                                        v-on:click="guardarUsuario(userData.selectedUsuario)"><i
                                                            class="fas fa-check m"></i>Guardar</button>
                                                    <button class="boton anima enfasis primario-b negro-t s bold"
                                                        style="--color: var(--primario); --texto:var(--negro)"
                                                        v-on:click="cambiarContrasena(userData.selectedUsuario)"><i
                                                            class="fas fa-check m"></i>Cambiar Contraseña</button>
                                                    <button class="boton anima enfasis primario-b rojo-t s bold"
                                                        style="--color: var(--advertencia); --texto:var(--negro)"
                                                        v-on:click="eliminar(userData.selectedUsuario)">
                                                        <i class="fas fa-trash m"></i>Eliminar
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>
</template>