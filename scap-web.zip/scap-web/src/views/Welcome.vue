<script setup lang="ts">

</script>
<template>
    <div class="login-screen">
        <span class="titulo enfasis blanco-t xxl bold">Bienvendo a SCAP</span>
    </div>
</template>