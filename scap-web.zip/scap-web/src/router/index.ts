import Definitivo from "@/views/Definitivo.vue";
import Formato from "@/views/Formato.vue";
import Roles from "@/views/Roles.vue";
import Usuarios from "@/views/Usuarios.vue";
import Welcome from "@/views/Welcome.vue";
import { createRouter, createWebHistory } from "vue-router";
import Crud from "../pages/Crud.vue";
import Login from "../views/Login.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: 'welcome',
      component: Welcome
    },
    {
      path: "/roles",
      name: 'roles',
      component: Roles,
      
    },
    {
      path: "/usuarios",
      name: 'usuarios',
      component: Usuarios
    },
    {
      path: "/descarga",
      name: "descarga",
      component: Definitivo
    },
    {
      path: "/formato",
      name: "formato",
      component: Formato
    },
    {
      path: "/:form",
      name: "home",
      component: Crud,
    },
    {
      path: "/login",
      name: "login",
      component: Login,
    },
  ],
});

router.beforeEach((to, from, next) => {
  console.log('to', to);
  const publicPages = ['/login'];
  const authRequired = !publicPages.includes(to.path);
  const loggedIn = localStorage.getItem('user');


  if (authRequired && !loggedIn) {
    next('/login');
  } else {
    next();
  }
});
export default router;
