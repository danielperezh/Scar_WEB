import axios from 'axios';

let link = 'http://localhost:8080';
if(location.href.indexOf('localhost')<0)
    link = `${location.protocol}//${location.hostname}:8082`

const API_URL = link+ '/auth/';
class AuthService {
  login(user) {
    return axios
      .post(API_URL + 'signin',
          {
            username: user.username,
            password: user.password
          })
      .then(response => {
        if (response.data.token) {
          localStorage.setItem('user', JSON.stringify(response.data));
        }
        return response.data;
      });
  }

  logout() {
    localStorage.removeItem('user');
  }

  register(user) {
    return axios.post(API_URL + 'signup', {
      username: user.username,
      email: user.email,
      password: user.password
    });
  }
}

export default new AuthService();
