import { DESCARGAS, DESMANTELADOS_PLANTILLA, DESMANTELAMIENTO_ARCGIS, FORMATOS, INVENTARIO, LINEA, NO_RECONOCIDOS, OTRAS_VIGENCIAS, PLANTILLA, RECHAZADOS, ROLES, SUBESTACION, USER, USUARIOS, VALIDACION } from '@/interfaces';
import router from '@/router';
import { defineStore } from 'pinia';

 interface Menu {
    titulo: string,
    vinculo?: string,
    icono?: string,
    elementos?: Array<Menu>,
    rol?: string
}

export const useMenuStore = defineStore('menu', () => {

    const menuAdmin = [
        {
            titulo: 'ACTIVOS',
            icono: 'fas fa-cogs',
            elementos: [
                {
                    titulo: 'Subestaciones',
                    vinculo: 'subestacion',
                    rol: SUBESTACION
                },
                {
                    titulo: 'Linea',
                    vinculo: 'linea',
                    rol: LINEA
                }, {
                    titulo: 'Inventario',
                    vinculo: 'inventario',
                    rol: INVENTARIO
                },
                {
                    titulo: 'No reconocidos',
                    vinculo: 'noReconocido',
                    rol: NO_RECONOCIDOS
                },
                {
                    titulo: 'Reporte otras vigencias',
                    vinculo: 'otraVigencia',
                    rol: OTRAS_VIGENCIAS
                },
                {
                    titulo: 'Descargas',
                    vinculo: 'descarga',
                    rol: DESCARGAS
                }
            ]
        },
        {
            titulo: 'Dados de baja',
            icono: 'fas fa-cogs',
            elementos: [
                {
                    titulo: 'Desmontados',
                    vinculo: 'validainventario',
                    rol: DESMANTELAMIENTO_ARCGIS
                },
                {
                    titulo: 'Brafo',
                    vinculo: 'desmanteladoBrafo',
                    rol: DESMANTELAMIENTO_ARCGIS
                }
            ]
        },
        {
            titulo: 'GESTIÓN PLANTILLAS',
            icono: 'fas fa-cogs',
            elementos: [
                {
                    titulo: 'Plantilla',
                    vinculo: 'plantilla',
                    rol: PLANTILLA
                }, {
                    titulo: 'Plantilla Arcgis',
                    vinculo: 'plantillaArcgis',
                    rol: PLANTILLA
                }, {
                    titulo: 'Rechazados',
                    vinculo: 'rechazados',
                    rol: RECHAZADOS
                }, {
                    titulo: 'Desmantelados',
                    vinculo: 'desmantelados',
                    rol: DESMANTELADOS_PLANTILLA
                }
            ]
        },
        {
            titulo: 'Formatos Regulatorios',
            icono: 'fas fa-cogs',
            elementos: [
                {
                    titulo: 'Formatos',
                    vinculo: 'formato',
                    rol: FORMATOS
                }
            ]
        },
        {
            titulo: 'Validación',
            vinculo: 'listado',
            icono: 'fas fa-cogs',
            elementos: [
                {
                    titulo: 'Validación',
                    vinculo: 'validacion',
                    rol: VALIDACION
                }
            ]
        },
        {
            titulo: 'Usuarios',
            icono: 'fas fa-user',
            elementos: [
                {
                    titulo: 'Usuarios',
                    vinculo: 'usuarios',
                    rol: USUARIOS
                }, {
                    titulo: 'Roles',
                    vinculo: 'roles',
                    rol: ROLES
                }
            ]

        }
    ] as Array<Menu>;
    const menu = menuAdmin;
    //cerrar submenus


    const cerrar = () => {

        const s: any = document.getElementById('cerrar');
        s!.checked = true;

    }

    //Obtener posicion menu e indicador
    const getPos = (e: any) => {
        const btnMenu = document.getElementById('btn-menu' + e);
        const objMenu = document.getElementById('menu' + e);
        const innerMenu = document.getElementById('innerMenu');
        const ind = document.getElementById('in' + e);
        const desplazamiento = btnMenu!.offsetTop - innerMenu!.scrollTop - 5;
        const tam = objMenu!.offsetHeight;
        const vh = window.innerHeight;
        ind!.style.top = (desplazamiento + 40) + 'px';
        if (desplazamiento + 80 + tam > vh || tam > (vh - 40) / 2) {
            objMenu!.style.top = '';
            objMenu!.style.bottom = '50px';
        } else {
            objMenu!.style.bottom = '';
            objMenu!.style.top = (desplazamiento) + 'px'
        }


    }

    //Filtrar menu
    const filtrarMenu = (user: any, maninMenu = menu) => {
        console.log('filtro');
        if(!user?.roles?.length) {
            router.push('/login');
            return [];
        }
        const localMenu = [];
        if(Array.isArray(maninMenu)) {
            for(let m of maninMenu) {
                let added = false;
                if(m.rol && user.roles.includes(m.rol)) {
                    localMenu.push(m);
                    added = true;
                }
                if(m.elementos?.length) {
                    let ele: Array<Menu> = filtrarMenu(user, m.elementos);
                    if(ele?.length && !added) {
                        localMenu.push({...m, elementos: ele})
                    }
                }
            }
        }
        return localMenu;
    }

    //Indicadores de navegacion scroll

    const scrollFunction = () => {
        const innerMenu = document.getElementById('innerMenu');
        const upd = document.getElementById('up');
        const downd = document.getElementById('down');
        const tam = innerMenu!.scrollHeight;
        const tamC = innerMenu!.clientHeight;
        if (innerMenu!.scrollTop > 50) {
            upd!.style!.opacity = '1';
        } else {
            upd!.style!.opacity = '0';
        }

        if (innerMenu!.scrollTop < tam - tamC - 40) {
            downd!.style.opacity = '1';
        } else {
            downd!.style.opacity = '0';
        }


    }
    return {
        cerrar,
        getPos,
        scrollFunction,
        filtrarMenu
    }
})
