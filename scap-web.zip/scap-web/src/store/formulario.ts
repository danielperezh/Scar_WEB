import { defineStore } from "pinia";
import { ref } from "vue";
import axios from 'axios';
import { CARGAR_PLANTILLA, CARGAR_PLANTILLA_CAPITALIZACION, DESMANTELADOS_PLANTILLA, DESMANTELAMIENTO_ARCGIS, ENVIAR_INVENTARIO, EXPORTAR_ARCGIS, EXPORTAR_INVENTARIO, EXPORTAR_SAP, PLANTILLA, VALIDAR_INVENTARIO } from "@/interfaces";
interface Validacion  {id: string, equipo: string, campo: string, permiso: string};
let remplazarNulos: Validacion[] = [];


let link = 'http://localhost:8080';
if(location.href.indexOf('localhost')<0)
    link = `${location.protocol}//${location.hostname}:8082`

const url = link +'/scap/inventario'

const descripcion = {
    etiqueta: "Descripción",
    valor: "texto",
    tipoCampo: "label",
    icono: "fa-solid fa-user",
    crear: true,
    nombreCampo: 'descripcion'
};
const nombre = {
    etiqueta: "Nombre",
    valor: "texto",
    tipoCampo: "label",
    icono: "fa-solid fa-user",
    crear: true,
    nombreCampo: 'nombre'
};
const opcionesCalibre = [
    {
        nombre: '',
        value: null
    },
    {
        nombre: '14 AWG',
        valor: '14 AWG'
    },
    {
        nombre: '12 AWG',
        valor: '12 AWG'
    },
    {
        nombre: '10 AWG',
        valor: '10 AWG'
    },
    {
        nombre: '8 AWG',
        valor: '8 AWG'
    },
    {
        nombre: '6 AWG',
        valor: '6 AWG'
    },
    {
        nombre: '4 AWG',
        valor: '4 AWG'
    },
    {
        nombre: '2 AWG',
        valor: '2 AWG'
    },
    {
        nombre: '1 AWG',
        valor: '1 AWG'
    },
    {
        nombre: '1/0 AWG',
        valor: '1/0 AWG'
    },
    {
        nombre: '2/0 AWG',
        valor: '2/0 AWG'
    },
    {
        nombre: '3/0 AWG',
        valor: '3/0 AWG'
    },
    {
        nombre: '4/0 AWG',
        valor: '4/0 AWG'
    },
    {
        nombre: '6/0 AWG',
        valor: '6/0 AWG'
    },
    {
        nombre: '180 kcmil',
        valor: '180 kcmil'
    },
    {
        nombre: '250 kcmil',
        valor: '250 kcmil'
    },
    {
        nombre: '266 kcmil',
        valor: '266 kcmil'
    },
    {
        nombre: '300 kcmil',
        valor: '300 kcmil'
    },
    {
        nombre: '336 kcmil',
        valor: '336 kcmil'
    },
    {
        nombre: '350 kcmil',
        valor: '350 kcmil'
    },
    {
        nombre: '397 kcmil',
        valor: '397 kcmil'
    },
    {
        nombre: '400 kcmil',
        valor: '400 kcmil'
    },
    {
        nombre: '477 kcmil',
        valor: '477 kcmil'
    },
    {
        nombre: '500 kcmil',
        valor: '500 kcmil'
    },
    {
        nombre: '600 kcmil',
        valor: '600 kcmil'
    },
    {
        nombre: '605 kcmil',
        valor: '605 kcmil'
    },
    {
        nombre: '750 kcmil',
        valor: '750 kcmil'
    },
    {
        nombre: '795 kcmil',
        valor: '795 kcmil'
    }
];
const opcionesTensionNominal = [
    {
        nombre: '',
        value: null
    },
    {
        nombre: '0.6',
        valor: '0.6'
    },
    {
        nombre: '0.24',
        valor: '0.24'
    },
    {
        nombre: '0.3',
        valor: '0.3'
    },
    {
        nombre: '0.127',
        valor: '0.127'
    },
    {
        nombre: '13.8',
        valor: '13.8'
    },
    {
        nombre: '15',
        valor: '15'
    },
    {
        nombre: '15.5',
        valor: '15.5'
    },
    {
        nombre: '34.5',
        valor: '34.5'
    },
    {
        nombre: '36',
        valor: '36'
    },
    {
        nombre: '38',
        valor: '38'
    },
    {
        nombre: '110',
        valor: '110'
    },
    {
        nombre: '115',
        valor: '115'
    },
    {
        nombre: '120',
        valor: '120'
    },
    {
        nombre: '123',
        valor: '123'
    },
    {
        nombre: '125',
        valor: '125'
    },
    {
        nombre: '220',
        valor: '220'
    },
    {
        nombre: '230',
        valor: '230'
    }
];

const opcionesSiNoM = [
    {
        nombre: '',
        value: null
    },
    {
        nombre: 'Si',
        valor: 'SI'
    },
    {
        nombre: 'No',
        valor: 'NO'
    }
];

const opcionesCeroUno = [
    {
        nombre: '',
        value: null
    },
    {
        nombre: 'Si',
        valor: '1'
    },
    {
        nombre: 'No',
        valor: '0'
    }
];

const opcionesSN = [
    {
        nombre: '',
        value: null
    },
    {
        nombre: 'Si',
        valor: 'S'
    },
    {
        nombre: 'No',
        valor: 'N'
    }
];


export const useFormularioStore = defineStore('formulario', () => {
    let parametrizacion: any = {
        caracteristicas: {
            titulo: 'Caraterísticas',
            campos: [
                descripcion
            ]
        },
        equipo: {
            titulo: 'Equipos',
            campos: [
                nombre
            ]
        },
        listado: {
            titulo: 'Listado',
            campos: [
            ]
        },
        marcaFabricante: {
            titulo: 'Marca de Fabricante',
            url: 'marca-fabricante',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta: 'Código',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
                }, {
                    etiqueta: 'Nombre',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nombre'
                }
            ]
        },
        grupoCalidad: {
            titulo: 'Grupo de Calidad',
            url: 'grupo-calidad',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta: 'Identificador',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
                }, {
                    etiqueta: 'Valor',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorGrupo'
                }
            ]
        },
        faseAlimentacion: {
            titulo: 'Fase de Alimentación',
            url: 'fase-alimentacion',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta: 'Identificador',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
                }, {
                    etiqueta: 'Descripción',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'descripcion'
                }
            ]
        },
        linea: {
            titulo: 'Línea',
            url: 'linea', 
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta: 'Identificador',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: false,
                    nombreCampo: 'id',
                    deshabilitado: true
            },
                {
                    etiqueta: 'Código de Línea',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codLinea',
                    deshabilitado: true
            },
                {
                    etiqueta: 'IUL Límite',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iulLimite'
                },
                {
                    etiqueta: 'Nombre de Subestación',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nomSubestacion'
            },
                {
                    etiqueta: 'Código de Subestación',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codSubestacion'
            },
                {
                    etiqueta: 'Nombre de Circuito',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nomCircuito'
            },
                {
                    etiqueta: 'Ius Inicial',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusInicial'
            },
                {
                    etiqueta: 'Nombre Ius Inicial',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nomIusInicial'
            },
                {
                    etiqueta: 'Ius Final',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusFinal'
            },
                {
                    etiqueta: 'Nombre Ius Final',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nomIusFinal'
            },
                {
                    etiqueta: 'Tensión de Operación',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionOperacion'
            },
                {
                    etiqueta: 'Nivel de Tensión',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelTension'
            },
                {
                    etiqueta: 'Operación',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'operacion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'Sí',
                            valor: 'S'
                        }, {
                            nombre: 'No',
                            valor: 'N'
                        }
                    ]
            },
                {
                    etiqueta: 'Observaciones',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'observaciones'
            },
                {
                    etiqueta: 'Incluido Plan de Inversión',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'incluidoPlanInversion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'Sí',
                            valor: 'S'
                        }, {
                            nombre: 'No',
                            valor: 'N'
                        }
                    ]
                },
                {
                    etiqueta: 'Municipio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'municipio'
                },
                {
                    etiqueta: 'Zona',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'zona'
                },
                {
                    etiqueta: 'Configuración de Circuito',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'configuracionCircuito'
                },
            ]
        },
        categoria: {
            titulo: 'Categoría',
            url: 'categoria',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta: 'Identificador',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
                }, {
                    etiqueta: 'Descripción',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'descripcion'
                }
            ]
        },
        subestacion: {
            titulo: 'Subestación',
            url: 'subestacion',
            agregar: true,
            editar: true,
            campos:  [
                {
                    etiqueta: 'Ius',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: false,
                    nombreCampo: 'id',
                    deshabilitado: true
            },
                {
                    etiqueta: 'Código de subestación',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoSubestacion'
                },
                {
                    etiqueta: 'Nombre de Subestación',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nombreSubestacion'
            },                
                {
                    etiqueta: 'Tipo de Inventario',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoInventario',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre:'CRI',
                            valor: 'CRI'
                        },
                        {
                            nombre:'CRINR',
                            valor: 'CRINR'
                        },
                        {
                            nombre:'BRAFO',
                            valor: 'BRAFO'
                        },
                        {
                            nombre:'CRIN',
                            valor: 'CRIN'
                        },                     
                        {
                            nombre:'INVA',
                            valor: 'INVA'
                        },
                        {
                            nombre:'BRAEN',
                            valor: 'BRAEN'
                        }
                    ]
            },
            {
                etiqueta: 'Salinidad',
                valor: '',
                filtro: true,
                tipoCampo: 'dropdown',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'salinidad',
                opciones: [
                    {
                        nombre: '',
                        valor: null
                    },
                    {
                        nombre: 'Sí',
                        valor: 'S'
                    }, {
                        nombre: 'No',
                        valor: 'N'
                    }
                ]
        },
            {
                etiqueta: 'Operación',
                valor: '',
                filtro: true,
                tipoCampo: 'dropdown',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'operacion',
                opciones: [
                    {
                        nombre: '',
                        valor: null
                    },
                    {
                        nombre: 'Sí',
                        valor: 'S'
                    }, {
                        nombre: 'No',
                        valor: 'N'
                    }
                ]
        },
            {
                etiqueta: 'Estado',
                valor: '',
                filtro: true,
                tipoCampo: 'dropdown',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'estado',
                opciones: [
                    {
                        nombre: '',
                        valor: null
                    },
                    {
                        nombre: '1',
                        valor: 1
                    },
                    {
                        nombre: '2',
                        valor: 2
                    },
                    {
                        nombre: '3',
                        valor: 3
                    }
                ]
        },
            {
                etiqueta: 'Observaciones',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'observaciones'
        },
            {
                etiqueta: 'Incluido Plan de Inversion',
                valor: '',
                filtro: true,
                tipoCampo: 'dropdown',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'incluidoPlanInversion',
                opciones: [
                    {
                        nombre: '',
                        valor: null
                    },
                    {
                        nombre: 'Sí',
                        valor: 1
                    }, {
                        nombre: 'No',
                        valor: 0
                    }
                ]
        },
            {
                etiqueta: 'Propiedad',
                valor: '',
                filtro: true,
                tipoCampo: 'dropdown',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'propiedad',
                opciones: [
                    {
                        nombre: '',
                        valor: null
                    },
                    {
                        nombre: 'EBSA',
                        valor: 'EBSA'
                    },
                    {
                        nombre: 'CENS',
                        valor: 'CENS'
                    },
                    {
                        nombre: 'CODENSA',
                        valor: 'CODENSA'
                    },
                    {
                        nombre: 'ENERCA',
                        valor: 'ENERCA'
                    },
                    {
                        nombre: 'EPM',
                        valor: 'EPM'
                    },
                    {
                        nombre: 'ESSA',
                        valor: 'ESSA'
                    },
                    {
                        nombre: 'INVA',
                        valor: 'INVA'
                    }
                ]
        },
            {
                etiqueta: 'Alternativa',
                valor: '',
                filtro: true,
                tipoCampo: 'dropdown',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'alternativa',
                opciones: [
                    {
                        nombre: '',
                        valor: null
                    },
                    {
                        nombre: '1',
                        valor: 1
                    },
                    {
                        nombre: '2',
                        valor: 2
                    },
                    {
                        nombre: '3',
                        valor: 3
                    },
                    {
                        nombre: '4',
                        valor: 4
                    },
                    {
                        nombre: '5',
                        valor: 5
                    },
                    {
                        nombre: '6',
                        valor: 6
                    }
                ]
            },
                {
                    etiqueta: 'Código de Proyecto',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoProyecto'
            },
                {
                    etiqueta: 'Longitud',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitud'
            },
                {
                    etiqueta: 'Latitud',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitud'
            },
                {
                    etiqueta: 'Altitud',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'altitud'
            },
                {
                    etiqueta: 'Área',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'area'
            },
                {
                    etiqueta: 'Valor Catastral',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorCatastral'
            },
                {
                    etiqueta: 'Municipio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'municipio'
                },
                {
                    etiqueta: 'Zona',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'zona'
                },
                {
                    etiqueta: 'Código de Zona',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoZona',
                    minimo: 0,
                    maximo: 9999,
                    maxDigitos: 4,
                },
                {
                    etiqueta: 'Código de configuración subestación',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoConfigruacionSubestacion',
                    minimo: 0,
                    maximo: 9999,
                },
                {
                    etiqueta: 'Configuración de subestación',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'configuracionSubestacion',
                },
                {
                    etiqueta: 'Tipo de Subestación',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoSubestacion',
                    opciones: [
                        {
                            nombre: 'GIS',
                            valor: 'GIS'
                        },
                        {
                            nombre: 'AIS',
                            valor: 'AIS'
                        }
                    ]
                },
                {
                    etiqueta: 'PSN',
                    valor: '',
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'psn',
                    minimo: 0,
                    maximo: 99999999,
                    maxDigitos: 8,
                },
                {
                    etiqueta: 'Nivel de tensión',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelTension',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '1',
                            valor: '1'
                        },
                        {
                            nombre: '2',
                            valor: '2'
                        },
                        {
                            nombre: '3',
                            valor: '3'
                        },
                        {
                            nombre: '4',
                            valor: '4'
                        },
                        {
                            nombre: '5',
                            valor: '5'
                        }
                    ]
                },
            ]
        },
        usuario : {
            titulo: 'Gestion de usuarios',
            url: 'usuario',
            agregar: true,
            campos: [
                {
                    etiqueta: 'Id',
                    tipoCampo: 'input text',
                    nombreCampo: 'id',
                    deshabilitado: true, 
                    crear: false
                },
                {
                    etiqueta: 'Usuario',
                    tipoCampo: 'input text',
                    nombreCampo: 'usuario',
                    crear: true
                },
                {
                    etiqueta: 'Contraseña',
                    tipoCampo: 'input text',
                    nombreCampo: 'contrasena',
                    crear: true
                },
                {
                    etiqueta: 'Roles',
                    tipoCampo: 'listado',
                    nombreCampo: 'roles',
                    crear: true,
                    lista: ['ROLE_ADMIN', 'ROLE_APROBADOR', 'ROLE_INVENTARIO', 'ROLE_REPORTES', 'ROLE_CARGADOR']
                }
            ],
            masivo: [
                {
                    titulo: 'Cambiar Contraseña',
                    valor: 'N',
                    campo: 'newPass',
                    campoObservacion: 'contrasena',
                    textoObservacion: 'Nueva Contraseña'
                }
            ]
        },
        inventario: {
            titulo: 'Inventario',
            url: 'matriz-subestacion',
            agregar: false,
            editar: true,
            global: {
                campo: 'alcance',
                etiqueta: 'Alcance'
            },
            filtro: {
                definitivo: 0
            },
            acciones: [
                {
                    titulo: 'Validación',
                    rol: VALIDAR_INVENTARIO,
                    icono: 'fa-file-excel',
                    accion: async (callback: any, filter:any=undefined) => {
                        const resultado = confirm('Este proceso se demora un momento, ¿Desea continuar?');
                        if(!resultado)
                            return;
                        window.open(url + '/matriz-subestacion/validacion?alcance='+filter)
                    }

                },
                {
                    titulo: 'SAP',
                    rol: EXPORTAR_SAP,
                    icono: 'fa-file-excel',
                    accion: async (message: any, filter:any) => {
                        let link = url + '/matriz-subestacion/sap?alcance=' + filter
                        console.log(link);
                        window.open(link);
                    }
            },
            {
                titulo: 'Inventario Definitivo',
                rol: EXPORTAR_INVENTARIO,
                icono: 'fa-check',
                accion: async (callback: (mensaje: string) => void, filter: any) => {
                    const resultado = confirm('Esta acción es definitiva, ya no se podrá editar el inventario actual');
                    if(!resultado)
                        return;
                    await axios.get(url + '/matriz-subestacion/definitivo?alcance=' + filter).then(data => {
                        if(data.data?.mensaje) {
                            callback(data.data.mensaje)
                        }
                    }, (rechazo => {
                        const mensaje = ((rechazo.mensaje ?? rechazo.data?.mensaje) ?? rechazo.response?.mensaje) ?? rechazo.response?.data?.mensaje;
                        console.log(rechazo, mensaje);
                        if(mensaje) {
                            callback(mensaje);
                        }
                    }));
                }
            }
            ],
            masivo: [],
            crear: true,
            valorNulo: (data: any, nombreCampo: string) => {
                const busqueda = (element: Validacion) =>{
                    return ('descriptor' in data && data.descriptor == element.equipo && nombreCampo == element.campo && (element.permiso == 'R' || element.permiso == 'O'));
                };
                if(!remplazarNulos?.length)
                    return ''
                let elemento = remplazarNulos.find(busqueda)
                return elemento ? (elemento.permiso === 'R' ? 'Requerido' :'opcional'): '';
            },
            campos: [
                {
                    etiqueta: 'Identificador de Plantilla',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id',
                    fijo: true,
                    deshabilitado: true
                },
                {
                    etiqueta: 'Tipo de Archivo',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoArchivo',
                    formato: '********************',
                    deshabilitado: true,
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'SUBESTACIONES',
                            valor: 'SUBESTACIONES'
                        },
                        {
                            nombre: 'TRAFOS_DISTRI',
                            valor: 'TRAFOS_DISTRI'
                        },
                        {
                            nombre: 'LINEAS_DISTRI',
                            valor: 'LINEAS_DISTRI'
                        },
                        {
                            nombre: 'LINEAS',
                            valor: 'LINEAS'
                        }
                    ]
                },
                {
                    etiqueta: 'Latitud Inicial',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitudInicial',
                    minimo: -999,
                    maximo: 999,
                    maxDigitos: 15,
                    deshabilitado: true
            },
                {
                    etiqueta: 'Longitud inicial',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitudInicial',
                    minimo: -999,
                    maximo: 999,
                    maxDigitos: 15,
                    dehsabilitado: true
            },
                {
                    etiqueta: 'Iua',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iua',
                    formato: '*************',
                    deshabilitado: true
            },
                {
                    etiqueta: 'Ius Subestacion',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusSubestacion'
            },
                {
                    etiqueta: 'Iul Linea',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iulLinea'
            },
                {
                    etiqueta: 'Fecha de Calibracion',
                    filtro: true,
                    tipoCampo: 'fecha',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fechaCalibracion'
            },
                {
                    etiqueta: 'Uc Asimilada',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ucAsimilada',
                    formato: '********'
            },
                {
                    etiqueta: 'Código de Elemento Uc',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codElementoUc',
                    formato: '**********'
            },
                {
                    etiqueta: 'Marca de Fabricante',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'marcaFabricante',
                    maximo: 9999,
                    minimo: 0
            },
                {
                    etiqueta: 'Serie de Fabricante',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'serieFabricante',
                    formato: '**************************************************'
            },
                {
                    etiqueta: 'Año de Fabricacion',
                    filtro: true,
                    tipoCampo: 'fecha',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'anoFabricacion',
                    tipoFecha: 'ano',
                    formato: 'yyyy'
            },
                {
                    etiqueta: 'Version de Software',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'versionSoftware',
                    formato: '**********'
            },
                {
                    etiqueta: 'protocolos',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'Protocolos',
                    formato: '***************'
            },
                {
                    etiqueta: 'Capacidad Nominal',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capacidadNominal',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '5',
                            valor: '5'
                        },
                        {
                            nombre: '7.5',
                            valor: '7.5'
                        },
                        {
                            nombre: '10',
                            valor: '10'
                        },
                        {
                            nombre: '15',
                            valor: '15'
                        },
                        {
                            nombre: '20',
                            valor: '20'
                        },
                        {
                            nombre: '25',
                            valor: '25'
                        },
                        {
                            nombre: '30',
                            valor: '30'
                        },
                        {
                            nombre: '37.5',
                            valor: '37.5'
                        },
                        {
                            nombre: '45',
                            valor: '45'
                        },
                        {
                            nombre: '50',
                            valor: '50'
                        },
                        {
                            nombre: '75',
                            valor: '75'
                        },
                        {
                            nombre: '112.5',
                            valor: '112.5'
                        },
                        {
                            nombre: '150',
                            valor: '150'
                        },
                        {
                            nombre: '225',
                            valor: '225'
                        },
                        {
                            nombre: '250',
                            valor: '250'
                        },
                        {
                            nombre: '300',
                            valor: '300'
                        },
                        {
                            nombre: '400',
                            valor: '400'
                        },
                        {
                            nombre: '500',
                            valor: '500'
                        },
                        {
                            nombre: '630',
                            valor: '630'
                        },
                        {
                            nombre: '1000',
                        valor: '1000'
                        }
                    ]
            },
                {
                    etiqueta: 'Tipo  de Refrigeracion',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoRefrigeracion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'ONAN',
                            valor: 'ONAN'
                        },
                        {
                            nombre: 'ONAF',
                            valor: 'ONAF'
                        },
                        {
                            nombre: 'OFAF',
                            valor: 'OFAF'
                        },
                        {
                            nombre: 'ONAF-ONAN',
                        valor: 'ONAF-ONAN'
                        }
                    ]
            },
                {
                    etiqueta: 'Grupo de Conexión',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grupoConexion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'L i 0',
                            valor: 'L i 0'
                        }
                        ,   
                        {
                            nombre: 'L i 6',
                            valor: 'L i 6'
                        }
                        ,   
                        {
                            nombre: 'Yz',
                            valor: 'Yz'
                        }
                        ,   
                        {
                            nombre:  'Ynad1',
                            valor:  'Ynad1'
                        }
                        ,   
                        {
                            nombre: 'Yna0d1',
                            valor: 'Yna0d1'
                        }
                        ,   
                        {
                            nombre: 'Yna0(d1)',
                            valor: 'Yna0(d1)'
                        }
                        ,   
                        {
                            nombre: 'YNyn0yn0(d)',
                            valor: 'YNyn0yn0(d)'
                        }
                        ,   
                        {
                            nombre: 'YNd11',
                            valor: 'YNd11'
                        }
                        ,   
                        {
                            nombre: 'Dd0',
                            valor: 'Dd0'
                        }
                        ,   
                        {
                            nombre: 'Dyn5',
                            valor: 'Dyn5'
                        }
                        ,   
                        {
                            nombre: 'YNynd11',
                            valor: 'YNynd11'
                        }
                        ,   
                        {
                            nombre: 'YNYn0d11',
                            valor: 'YNYn0d11'
                        }
                        ,   
                        {
                            nombre: 'YNd11yn0',
                            valor: 'YNd11yn0'
                        }
                        ,   
                        {
                            nombre: 'YNyn0(d)',
                            valor: 'YNyn0(d)'
                        }
                        ,   
                        {
                            nombre: 'Dyn11',
                            valor: 'Dyn11'
                        }
                        ,   
                        {
                            nombre: 'YN11yn0',
                            valor: 'YN11yn0'
                        }
                        ,   
                        {
                            nombre: 'YNd1',
                            valor: 'YNd1'
                        }
                        ,   
                        {
                            nombre: 'Dyn1',
                            valor: 'Dyn1'
                        }
                        ,   
                        {
                                nombre: 'YNa0',
                                valor: 'YNa0'
                        }
                    ]   
            },
                {
                    etiqueta: 'Contador de Operaciones',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'contadorOperaciones',
                    maximo: 9999999999,
                    minimo: 0
            },
                {
                    etiqueta: 'Caracterización',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'caracterizacion',
                    opciones: opcionesSiNoM
            },
                {
                    etiqueta: 'Relacion de Transformacion',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'relacionTransformacion',
                    formato: '********************'
            },
                {
                    etiqueta: 'Impedancias',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'impedancias',
                    formato: '*****'
            },
                {
                    etiqueta: 'Resistencias',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'resistencias',
                    maximo: 9999999999,
                    minimo: 0
            },
                {
                    etiqueta: 'Bil',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'bil',
                    maximo: 9999,
                    minimo: 0
            },
                {
                    etiqueta: 'Corriente de Cortocircuito',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrienteCortocircuito',
                    maximo: 99,
                    maxDigitos: 3
            },
                {
                    etiqueta: 'Volumen de Aceite',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'volumenAceite',
                    maximo: 9999999999
            },
                {
                    etiqueta: 'Tipo de Núcleo',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoNucleo',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'ACORAZADO',
                            valor: 'ACORAZADO'
                        },
                        {
                            nombre: 'COLUMNA',
                            valor: 'COLUMNA'
                        }
                    ]
            },
                {
                    etiqueta: 'Medio Aislante',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'medioAislante',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'ACEITE',
                            valor: 'ACEITE'
                        },
                        {
                            nombre: 'ACEITE MINERAL',
                            valor: 'ACEITE MINERAL'
                        },
                        {
                            nombre: 'CLASE A',
                            valor: 'CLASE A'
                        },
                        {
                            nombre: 'GAS',
                            valor: 'GAS'
                        },
                        {
                            nombre: 'PXE',
                            valor: 'PXE'
                        },
                        {
                            nombre: 'SF6',
                            valor: 'SF6'
                        }
                    ]
            },
                {
                    etiqueta: 'Burden',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'burden',
                    maximo: 9999
            },
                {
                    etiqueta: 'Clase Medida',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'claseMedida',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'ACEITE',
                            valor: 'ACEITE'
                        },
                        {
                            nombre: 'ACEITE MINERAL',
                            valor: 'ACEITE MINERAL'
                        },
                        {
                            nombre: 'CLASE A',
                            valor: 'CLASE A'
                        },
                        {
                            nombre: 'GAS',
                            valor: 'GAS'
                        },
                        {
                            nombre: 'PXE',
                            valor: 'PXE'
                        },
                        {
                            nombre: 'SF6',
                            valor: 'SF6'
                        }
                    ]
            },
                {
                    etiqueta: 'Tensión Nominal',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionNominal',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '0.11',
                            valor: '0.11'
                        },
                        {
                            nombre: '0.12',
                            valor: '0.12'
                        },
                        {
                            nombre: '0.6',
                            valor: '0.6'
                        },
                        {
                            nombre: '0.24',
                            valor: '0.24'
                        },
                        {
                            nombre: '0.3',
                            valor: '0.3'
                        },
                        {
                            nombre: '0.127',
                            valor: '0.127'
                        },
                        {
                            nombre: '0.44',
                            valor: '0.44'
                        },
                        {
                            nombre: '13.8',
                            valor: '13.8'
                        },
                        {
                            nombre: '15',
                            valor: '15'
                        },
                        {
                            nombre: '15.5',
                            valor: '15.5'
                        },
                        {
                            nombre: '34.5',
                            valor: '34.5'
                        },
                        {
                            nombre: '36',
                            valor: '36'
                        },
                        {
                            nombre: '38',
                            valor: '38'
                        },
                        {
                            nombre: '110',
                            valor: '110'
                        },
                        {
                            nombre: '115',
                            valor: '115'
                        },
                        {
                            nombre: '120',
                            valor: '120'
                        },
                        {
                            nombre: '123',
                            valor: '123'
                        },
                        {
                            nombre: '125',
                            valor: '125'
                        },
                        {
                            nombre: '220',
                            valor: '220'
                        },
                        {
                            nombre: '230',
                            valor: '230'
                        }
                    ]
            },
                {
                    etiqueta: 'Corriente Primaria',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrientePrimaria',
                    formato: '**********'
            },
                {
                    etiqueta: 'Corriente Secundaria',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrienteSecundaria',
                    formato: '**********'
            },
                {
                    etiqueta: 'Cantidad de Núcleos',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidadNucleos',
                    maximo: 9999
            },
                {
                    etiqueta: 'Polos',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'polos',
                    maximo: 999
            },
                {
                    etiqueta: 'Tiempos de Actuación',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tiemposActuacion',
                    formato: '**********'
            },
                {
                    etiqueta: 'Resistencia Dinámica',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'resistenciaDinamica',
                    maximo: 9999
            },
                {
                    etiqueta: 'Número de bobinas',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroBobinas',
                    maximo: 999
            },
                {
                    etiqueta: 'Corriente Nominal',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrienteNominal',
                    maximo: 9999999999
            },
                {
                    etiqueta: 'Corriente Máximo Corte',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrienteMaxCorte',
                    maximo: 9999
            },
                {
                    etiqueta: 'Tipo de Apoyo',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoApoyo',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'POSTE',
                            valor: 'POSTE'
                        },
                        {
                            nombre: 'TORRE',
                            valor: 'TORRE'
                        },
                        {
                            nombre: 'ESTRUCTURA',
                            valor: 'ESTRUCTURA'
                        },
                        {
                            nombre: 'TORRECILLA',
                            valor: 'TORRECILLA'
                        }
                    ]
            },
                {
                    etiqueta: 'Material',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'material',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'ALUMINIO',
                            valor: 'ALUMINIO'
                        },
                        {
                            nombre: 'COBRE',
                            valor: 'COBRE'
                        },
                        {
                            nombre: 'CONCRETO',
                            valor: 'CONCRETO'
                        },
                        {
                            nombre: 'MADERA',
                            valor: 'MADERA'
                        },
                        {
                            nombre: 'FIBRA DE VIDRIO',
                            valor: 'FIBRA DE VIDRIO'
                        },
                        {
                            nombre: 'METALICO',
                            valor: 'METALICO'
                        }
                    ]
            },
                {
                    etiqueta: 'Altura de Apoyo',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'alturaApoyo',
                    maximo: 9999
            },
                {
                    etiqueta: 'Resistencia de Ruptura',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'resistenciaRuptura',
                    maximo: 9999
            },
                {
                    etiqueta: 'Función Estructura',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'funcionEstructura',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'RETENCION',
                            valor: 'RETENCION'
                        },
                        {
                            nombre: 'SUSPENSION',
                            valor: 'SUSPENSION'
                        }
                    ]
            },
                {
                    etiqueta: 'Código de tipo de estructura',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoTipoEstructura',
                    formato: '**********'
            },
                {
                    etiqueta: 'Tipo de Aislamiento',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoAislamiento',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'CERAMICA',
                            valor: 'CERAMICA'
                        },
                        {
                            nombre: 'PORCELANA',
                            valor: 'PORCELANA'
                        },
                        {
                            nombre: 'CAUCHO DE SILICONA',
                            valor: 'CAUCHO DE SILICONA'
                        },
                        {
                            nombre: 'POLIMERO',
                            valor: 'POLIMERO'
                        },
                        {
                            nombre: 'SINTETICO',
                            valor: 'SINTETICO'
                        },
                        {
                            nombre: 'VIDRIO',
                            valor: 'VIDRIO'
                        }
                    ]
            },
                {
                    etiqueta: 'Fotografias',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fotografias',
                    formato: '********************************************************************************************************************************************************************************************************'
            },
                {
                    etiqueta: 'Observaciones',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'observaciones',
                    formato: '********************************************************************************************************************************************************************************************************'
            },
                {
                    etiqueta: 'Propiedad',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'propiedad',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'EBSA',
                            valor: 'EBSA'
                        },
                        {
                            nombre: 'PARTICULAR',
                            valor: 'PARTICULAR'
                        },
                        {
                            nombre: 'FAER',
                            valor: 'FAER'
                        }
                    ]
            },
                {
                    etiqueta: 'Señalizacion de Seguridad',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'senalizacionSeguridad',
                    opciones: opcionesSiNoM
            },
                {
                    etiqueta: 'Nivel de Tensión',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelTension',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '1',
                            valor: '1'
                        },
                        {
                            nombre: '2',
                            valor: '2'
                        },
                        {
                            nombre: '3',
                            valor: '3'
                        },
                        {
                            nombre: '4',
                            valor: '4'
                        },
                        {
                            nombre: '5',
                            valor: '5'
                        }
                    ]
            },
                {
                    etiqueta: 'Latitud Final',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitudFinal',
                    maximo: 999,
                    minimo: -999,
                    maxDigitos: 15
            },
                {
                    etiqueta: 'Longitud Final',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitudFinal',
                    maximo: 999,
                    minimo: -999,
                    maxDigitos: 15
            },
                {
                    etiqueta: 'Tipo de Activo',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoActivo',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'USO',
                            valor: 'USO'
                        },
                        {
                            nombre: 'CONEXION',
                            valor: 'CONEXION'
                        }
                    ]
            },
                {
                    etiqueta: 'Tipo de Acometida',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoAcometida',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'AEREA',
                            valor: 'AEREA'
                        },
                        {
                            nombre: 'SUBTERRANEA',
                            valor: 'SUBTERRANEA'
                        }
                    ]
            },
                {
                    etiqueta: 'Calibre Conductor R',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreConductorR',
                    opciones: opcionesCalibre
            },
                {
                    etiqueta: 'Calibre Conductor S',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreConductorS',
                    opciones: opcionesCalibre
            },
                {
                    etiqueta: 'Calibre Conductor T',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreConductorT',
                    opciones: opcionesCalibre
            },
                {
                    etiqueta: 'Calibre Conductor N',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreConductorN',
                    opciones: opcionesCalibre
            },
                {
                    etiqueta: 'Conductor Ap',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'conductorAp',
                    opciones: opcionesCalibre
            },
                {
                    etiqueta: 'Calibre Cable Guarda',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreCableGuarda',
                    opciones: opcionesCalibre
            },
                {
                    etiqueta: 'Cantidad de Ductos',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidadDeDuctos',
                    maximo: 3
            },
                {
                    etiqueta: 'Diámetro de Ductos',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'diametroDuctos'
            },
                {
                    etiqueta: 'Configuración de Circuito',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'configuracionCircuito',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'RADIAL',
                            valor: 'RADIAL'
                        },
                        {
                            nombre: 'ANILLO',
                            valor: 'ANILLO'
                        }
                    ]
            },
                {
                    etiqueta: 'Nodo',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nodo',
                    formato: '**********'
            },
                {
                    etiqueta: 'Tipo de Transformador',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoTransformador',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'AÉREO',
                            valor: 'AÉREO'
                        },
                        {
                            nombre: 'PEDESTAL',
                            valor: 'PEDESTAL'
                        },
                        {
                            nombre: 'SUBESTACIÓN',
                            valor: 'SUBESTACIÓN'
                        }
                    ]
            },
                {
                    etiqueta: 'Tipo de Conexión',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoConexion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'MONOFASICO',
                            valor: 'MONOFASICO'
                        },
                        {
                            nombre: 'BIFASICO',
                            valor: 'BIFASICO'
                        },
                        {
                            nombre: 'TRIFASICO',
                            valor: 'TRIFASICO'
                        }
                    ]
            },
                {
                    etiqueta: 'Fase de Alimentacion',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'faseAlimentacion'
            },
                {
                    etiqueta: 'Número de Posiciones Taps',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroPosicionesTaps',
                    maximo: 999
            },
                {
                    etiqueta: 'Paso Tap',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'pasoTap',
                    formato: '***********'
            },
                {
                    etiqueta: 'Tap Nominal',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tapNominal',
                    maximo: 3,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Tensión Nominal Alta',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionNominalAlta',
                    opciones: opcionesTensionNominal
            },
                {
                    etiqueta: 'Tension Nominal Baja',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionNominalBaja',
                    opciones: opcionesTensionNominal
            },
                {
                    etiqueta: 'Tension Nominal Terciario',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionNominalTerciario',
                    opciones: opcionesTensionNominal
            },
                {
                    etiqueta: 'Trafos de Alumbrado',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'trafosAlumbrado',
                    opciones: opcionesSiNoM
            },
                {
                    etiqueta: 'Sistema Puesta a Tierra',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sistemaPuestaTierra',
                    opciones: opcionesSiNoM
            },
                {
                    etiqueta: 'Tipo de Alimentación',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoAlimentacion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'AC',
                            valor: 'AC'
                        },
                        {
                            nombre: 'DC',
                            valor: 'DC'
                        },
                        {
                            nombre: 'AC/DC',
                            valor: 'AC/DC'
                        }
                    ]
            },
                {
                    etiqueta: 'Equipos Térmicos',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'equiposTermicos',
                    opciones: opcionesSiNoM
            },
                {
                    etiqueta: 'Estado Operativo',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estadoOperativo',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'NC',
                            valor: 'NC'
                        },
                        {
                            nombre: 'NO',
                            valor: 'NO'
                        }
                    ]
            },
                {
                    etiqueta: 'Tipo Fibra',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoFibra',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'ADSS/OPGW',
                            valor: 'ADSS/OPGW'
                        },
                        {
                            nombre: 'ADSS',
                            valor: 'ADSS'
                        },
                        {
                            nombre: 'ADOSADA',
                            valor: 'ADOSADA'
                        }
                    ]
            },
                {
                    etiqueta: 'Peso',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'peso',
                    maximo: 9999999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Iua Elemento',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaElemento',
                    formato: '************'
            },
                {
                    etiqueta: 'Iua Reemplazo',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaReemplazo',
                    formato: '************'
            },
                {
                    etiqueta: 'Categoria',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'categoriaUc',
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Iua Trafo Potencia',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaTrafoPotencia',
                    formato: '************'
            },
                {
                    etiqueta: 'Fecha de Entrada en Operación',
                    filtro: true,
                    tipoCampo: 'fecha',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fechaEntradaOperacion',
                    formato: 'dd/mm/yyyy'
            },
                {
                    etiqueta: 'Fecha Salida Operacion',
                    filtro: true,
                    tipoCampo: 'fecha',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fechaSalidaOperacion',
                    formato: 'dd/mm/yyyy'
            },
                {
                    etiqueta: 'Sector',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sector',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'URBANO',
                            valor: 'URBANO'
                        },
                        {
                            nombre: 'RURAL',
                            valor: 'RURAL'
                        }
                    ]
            },
                {
                    etiqueta: 'Vida Útil Regulatoria',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'vidaUtilRegulatoria',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Código Ebsa Subestacion',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoEbsaSubestacion',
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Código Ebsa Línea',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoEbsaLinea',
                    formato: '**********'
            },
                {
                    etiqueta: 'Activo Construido',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'activoConstruido',
                    opciones: opcionesCeroUno
            },
                {
                    etiqueta: 'Activo Reconocido',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'activoReconocido',
                    opciones: opcionesCeroUno
            },
                {
                    etiqueta: 'Alternativa Valoracion',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'alternativaValoracion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'CRI',
                            valor: 'CRI'
                        },
                        {
                            nombre: 'CRINR',
                            valor: 'CRINR'
                        },
                        {
                            nombre: 'BRAFO',
                            valor: 'BRAFO'
                        },
                        {
                            nombre: 'CRIN',
                            valor: 'CRIN'
                        },
                        {
                            nombre: 'INVA',
                            valor: 'INVA'
                        },
                        {
                            nombre: 'BRAEN',
                            valor: 'BRAEN'
                        },
                        {
                            nombre: 'INVTR',
                            valor: 'INVTR'
                        }
                    ]
            },
                {
                    etiqueta: 'Altitud',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'altitud',
                    maximo: 9999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Antiguedad de Referencia',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'antiguedadReferencia',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'area',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'area',
                    maximo: 999999,
                    maxDigitos: 4
            },
                {
                    etiqueta: 'Área Especial',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'areaEspecial',
                    maximo: 999999,
                    maxDigitos: 4
            },
                {
                    etiqueta: 'Área Reconocida',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'areaReconocida',
                    maximo: 999999,
                    maxDigitos: 4
            },
                {
                    etiqueta: 'Cantidad Uc',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidadUc',
                    maximo: 99999,
                    maxDigitos: 4
            },
                {
                    etiqueta: 'Código Dane',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoDane',
                    maximo: 99999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Código de Proyecto',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoProyecto',
                    formato: '************'
            },
                {
                    etiqueta: 'Costo Regulatorio',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'costoRegulatorio',
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Costo Capital',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'costoCapital',
                    maximo: 9,
                    maxDigitos: 2
            },
                {
                    etiqueta: 'Estado Activo',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estadoActivo',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'Planeación',
                            valor: 'Planeación'
                        },
                        {
                            nombre: 'En Operación',
                            valor: 'En Operación'
                        },
                        {
                            nombre: 'Fuera de Operación',
                            valor: 'Fuera de Operación'
                        }
                    ]
            },
                {
                    etiqueta: 'Factor Secundario',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'factorSecundario',
                    maximo: 9,
                    maxDigitos: 4
            },
                {
                    etiqueta: 'Factor Terciario',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'factorTerciario',
                    maximo: 9,
                    maxDigitos: 4
            },
                {
                    etiqueta: 'Fracción Costo',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fraccionCosto',
                    maximo: 9,
                    maxDigitos: 2
            },
                {
                    etiqueta: 'fracción UC Reconocida',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fraccionUcReconocida',
                    maximo: 9,
                    maxDigitos: 2
            },
                {
                    etiqueta: 'Grupo Calidad',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grupoCalidad',
                    maximo: 99,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Horizonte de Reposicion',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'horizonteReposicion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '0',
                            valor: '0'
                        },
                        {
                            nombre: '1',
                            valor: '1'
                        },
                        {
                            nombre: '2',
                            valor: '2'
                        },
                        {
                            nombre: '3',
                            valor: '3'
                        }
                    ]
            },
                {
                    etiqueta: 'Id Plan',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'idPlan'
            },
                {
                    etiqueta: 'Incluido Plan de Inversion',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'incluidoPlanInversion',
                    opciones: opcionesCeroUno
            },
                {
                    etiqueta: 'Iua Provisional',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaProvisional',
                    formato: '************'
            },
                {
                    etiqueta: 'Iul Provisional',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iulProvisional',
                    formato: '****'
            },
                {
                    etiqueta: 'Ius Final',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusFinal',
                    formato: '****'
            },
                {
                    etiqueta: 'Ius Inicial',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusInicial',
                    formato: '****'
            },
                {
                    etiqueta: 'Ius Provisional',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusProvisional',
                    formato: '****'
            },
                {
                    etiqueta: 'Número de Apoyos',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroApoyos',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Número de conductores',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroConductores',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Número de fases',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroFases',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Número de usuarios',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroUsuarios',
                    maximo: 99999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Operación',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'operacion',
                    opciones: opcionesSN
            },
                {
                    etiqueta: 'Porcentaje de Apoyos',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'porcentajeApoyos',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Porcentaje de Conductores',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'porcentajeConductores',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Porcentaje de Uso',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'porcentajeUso',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Uc sin Nivel Tension',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ucSinNivelTension',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '1',
                            valor: '1'
                        },
                        {
                            nombre: '2',
                            valor: '2'
                        },
                        {
                            nombre: '3',
                            valor: '3'
                        }
                    ]
            },
                {
                    etiqueta: 'Remuneración Pendiente',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'remuneracionPendiente',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '1',
                            valor: '1'
                        },
                        {
                            nombre: '2',
                            valor: '2'
                        },
                        {
                            nombre: '3',
                            valor: '3'
                        }
                    ]
            },
                {
                    etiqueta: 'Ser Remplazado',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'serRemplazado',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '1',
                            valor: '1'
                        },
                        {
                            nombre: '2',
                            valor: '2'
                        }
                    ]
            },
                {
                    etiqueta: 'Resolución Entrada Operacion',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'resolucionEntradaOperacion',
                    formato: '************'
            },
                {
                    etiqueta: 'rpp',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'rpp',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '0',
                            valor: '0'
                        },
                        {
                            nombre: '1',
                            valor: '1'
                        }
                    ]
            },
                {
                    etiqueta: 'Salinidad',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'salinidad',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '1',
                            valor: '1'
                        },
                        {
                            nombre: '2',
                            valor: '2'
                        }
                    ]
            },
                {
                    etiqueta: 'circuitos Estructura',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'circuitosEstructura',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'SENCILLO',
                            valor: 'SENCILLO'
                        },
                        {
                            nombre: 'DOBLE',
                            valor: 'DOBLE'
                        },
                        {
                            nombre: 'TRIPLE',
                            valor: 'TRIPLE'
                        },
                        {
                            nombre: 'CUADRUPLE',
                            valor: 'CUADRUPLE'
                        }
                    ]
            },
                {
                    etiqueta: 'Proyectos Str Construcción',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'proyectosStrConstruccion',
                    opciones: opcionesSN
            },
                {
                    etiqueta: 'Estado Transformador',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estadoTransformador',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'Transformadores nuevos',
                            valor: 'TN'
                        },
                        {
                            nombre: 'Transformadores reparados parcialmente',
                            valor: 'TRP'
                        },
                        {
                            nombre: 'Transformadores reparados totalmente',
                            valor: 'TRT'
                        },
                        {
                            nombre: 'Transformadores reconstruidos',
                            valor: 'TRC'
                        }
                    ]
            },
                {
                    etiqueta: 'Tipo de Inversion',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoInversion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '1',
                            valor: '1'
                        },
                        {
                            nombre: '2',
                            valor: '2'
                        },
                        {
                            nombre: '3',
                            valor: '3'
                        },
                        {
                            nombre: '4',
                            valor: '4'
                        },
                        {
                            nombre: '5',
                            valor: '5'
                        }
                    ]
            },
                {
                    etiqueta: 'Tipo de Red',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoRed',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'AEREA',
                            valor: 'AEREA'
                        },
                        {
                            nombre: 'SUBTERRANEA',
                            valor: 'SUBTERRANEA'
                        }
                    ]
            },
                {
                    etiqueta: 'Tipo  de Reposición',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoReposicion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'RT',
                            valor: 'RT'
                        },
                        {
                            nombre: 'RC',
                            valor: 'RC'
                        },
                        {
                            nombre: 'RA',
                            valor: 'RA'
                        }
                    ]
            },
                {
                    etiqueta: 'Voltaje de Operación',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'voltajeOperacion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '0 (Fibra Optica)',
                            valor: '0 (Fibra Optica)'
                        },
                        {
                            nombre: '1 kV',
                            valor: '1 kV'
                        },
                        {
                            nombre: '13.2 kV',
                            valor: '13.2 kV'
                        },
                        {
                            nombre: '34.5 kV',
                            valor: '34.5 kV'
                        },
                        {
                            nombre: '115 kV',
                            valor: '115 kV'
                        },
                        {
                            nombre: '230 kV',
                            valor: '230 kV'
                        }
                    ]
                },
                {
                    etiqueta: 'Capítulo',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capitulo',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'CAP - 15',
                            valor: 'CAP - 15'
                        },
                        {
                            nombre: 'CAP - 14',
                            valor: 'CAP - 14'
                        }
                    ]
            },
                {
                    etiqueta: 'descriptor',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'descriptor',
                    formato: '********************************************************************************************************************************************************************************************************'
            },
                {
                    etiqueta: 'Unidad Constructiva',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'unidadConstructiva',
                    formato: '********'
            },
                {
                    etiqueta: 'Nivel Alta',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelAlta',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '3',
                            valor: '3'
                        },
                        {
                            nombre: '4',
                            valor: '4'
                        },
                        {
                            nombre: '5',
                            valor: '5'
                        }
                    ]
            },
                {
                    etiqueta: 'Nivel Baja Uno',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelBaja1',
                    formato: '*'
            },
                {
                    etiqueta: 'Nivel Baja Dos',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelBaja2',
                    formato: '*'
            },
                {
                    etiqueta: 'Nivel Baja tres',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelBaja3',
                    formato: '*'
            },
                {
                    etiqueta: 'Potencia Baja Uno',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'potenciaBaja1',
                    maximo: 99999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Potencia Baja Dos',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'potenciaBaja2',
                    maximo: 99999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Potencia Baja Tres',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'potenciaBaja3',
                    maximo: 99999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Sistema',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sistema',
                    formato: '***'
            },
                {
                    etiqueta: 'Disposición de Circuito',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'disposicionCircuito',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'VERTICAL',
                            valor: 'VERTICAL'
                        },
                        {
                            nombre: 'HORIZONTAL',
                            valor: 'HORIZONTAL'
                        }
                    ]
            },
                {
                    etiqueta: 'Cuerpos de Apoyo',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cuerposApoyo',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: '2',
                            valor: '2'
                        },
                        {
                            nombre: '3',
                            valor: '3'
                        }
                    ]
            },
                {
                    etiqueta: 'Reactancia',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'reactancia',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Susceptancia',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'susceptancia',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Denominación de Circuito',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'denominacionCircuito',
                    formato: '**************************************************'
            },
                {
                    etiqueta: 'Denominación de Subestacion',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'denominacionSubestacion',
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Configuración de Subestacion',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'configuracionSubestacion',
                    formato: '******************************'
            },
                {
                    etiqueta: 'Tipo de Subestación',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoSubestacion',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'AIS',
                            valor: 'AIS'
                        },
                        {
                            nombre: 'GIS',
                            valor: 'GIS'
                        },
                        {
                            nombre: 'AIS - GIS',
                            valor: 'AIS - GIS'
                        }
                    ]
            },
                {
                    etiqueta: 'Tipo de Conductor',
                    filtro: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoConductor',
                    opciones: [
                        {
                            nombre: '',
                            valor: null
                        },
                        {
                            nombre: 'ACSR',
                            valor: 'ACSR'
                        },
                        {
                            nombre: 'AAC',
                            valor: 'AAC'
                        },
                        {
                            nombre: 'AAAC',
                            valor: 'AAAC'
                        },
                        {
                            nombre: 'ACAR',
                            valor: 'ACAR'
                        },
                        {
                            nombre: 'EPR',
                            valor: 'EPR'
                        },
                        {
                            nombre: 'SEMIAISLADO',
                            valor: 'SEMIAISLADO'
                        }
                    ]
            },
                {
                    etiqueta: 'Capacidad Nominal MVA',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capacidadNominalMva',
                    maximo: 99999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Iul Inicial',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iulInicial',
                    formato: '**********'
            },
                {
                    etiqueta: 'Descripción de Elemento',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'descripcionElemento',
                    formato: '********************************************************************************************************************************************************************************************************'
            },
                {
                    etiqueta: 'Id Utility Network',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'idUtilityNetwork',
                    formato: '********'
            },
                {
                    etiqueta: 'Clase de Activos Fijos',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'claseActivosFijos',
                    formato: '********'
            },
                {
                    etiqueta: 'Denominación',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'denominacion',
                    formato: '**************************************************'
            },
                {
                    etiqueta: 'Texto Num Pral AF',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'textoNumPralAf',
                    formato: '**************************************************'
            },
                {
                    etiqueta: 'Número de Serie',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroSerie',
                    formato: '******************************'
            },
                {
                    etiqueta: 'Número de Inventario',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroInventario',
                    formato: '*************************'
            },
                {
                    etiqueta: 'Cantidad',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidad',
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Unidad de Medida',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'unidadMedida',
                    formato: '***'
            },
                {
                    etiqueta: 'se Gestiona Historicamente',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'seGestionaHistoricamente',
                    formato: '*'
            },
                {
                    etiqueta: 'Último Inventario',
                    filtro: true,
                    tipoCampo: 'fecha',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ultimoInventario'
            },
                {
                    etiqueta: 'Capitalizado',
                    filtro: true,
                    tipoCampo: 'fecha',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capitalizado'
            },
                {
                    etiqueta: 'Sociedad',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sociedad',
                    formato: '****'
            },
                {
                    etiqueta: 'Orden CO',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ordenCo',
                    formato: '************'
            },
                {
                    etiqueta: 'Centro de Costo',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'centroCoste',
                    formato: '**********'
            },
                {
                    etiqueta: 'Centro',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'centro',
                    formato: '****'
            },
                {
                    etiqueta: 'Emplazamiento',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'emplazamiento',
                    formato: '**********'
            },
                {
                    etiqueta: 'Local',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'local',
                    formato: '********'
            },
                {
                    etiqueta: 'Ubicación',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ubicacion',
                    formato: '****'
            },
                {
                    etiqueta: 'Número Personal',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroPersonal',
                    maximo: 99999999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Marca',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'marca',
                    formato: '****'
            },
                {
                    etiqueta: 'Tipo de Transformador',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoTransformador',
                    formato: '************'
            },
                {
                    etiqueta: 'Estado',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estado',
                    formato: '****'
            },
                {
                    etiqueta: 'Destino de Inversion',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'destinoInversion',
                    formato: '**'
            },
                {
                    etiqueta: 'Inv Protección del Medio Ambiente',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'invProtMedioAmb',
                    formato: '*****'
            },
                {
                    etiqueta: 'Clave Agrupamiento',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'claveAgrupamiento',
                    formato: '****'
            },
                {
                    etiqueta: 'Indicador de Propiedad',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'indicadorPropiedad',
                    formato: '*'
            },
                {
                    etiqueta: 'Fabricante',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fabricante',
                    formato: '******************************'
            },
                {
                    etiqueta: 'Parte Prod Propia',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'parteProdPropia',
                    maximo: 999999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Delegación Hacienda',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'delegacionHacienda',
                    formato: '*************************'
            },
                {
                    etiqueta: 'Nif Valor Unitario',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nifValorUnit',
                    formato: '****************'
            },
                {
                    etiqueta: 'Cartilla',
                    filtro: true,
                    tipoCampo: 'fecha',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cartilla'
            },
                {
                    etiqueta: 'Superficie',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'superficie',
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Um Superficie',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'umSuperficie',
                    maximo: 999,
                    maxDigitos: 0
            },
                {
                    etiqueta: 'Nota de Inventario',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'notaInventario',
                    formato: '***************'
            },
                {
                    etiqueta: 'Municipio',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'municipio',
                    formato: '*****'
            },
                {
                    etiqueta: 'Indicador de Tipo de Equipo',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'indicadorTipoEquipo',
                    formato: '***'
            },
                {
                    etiqueta: 'Subestación',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'subestacion',
                    formato: '******'
            },
                {
                    etiqueta: 'Modelo de Recálculo',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'modeloRecalculo',
                    formato: '**'
            },
                {
                    etiqueta: 'Amortizacion Normal',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'amortizacionNormal',
                    formato: '**********'
            },
                {
                    etiqueta: 'Importe Contabilización',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'importeContabiliz',
                    maxDigitos: 0
            },
                {
                    etiqueta: 'amortizacion Normal Acumulada',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'amortizacionNormalAcumulada',
                    maxDigitos: 0
            },
                {
                    etiqueta: 'centro de Planificación',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'centroPlanificacion',
                    formato: '****'
            },
                {
                    etiqueta: 'Emplazamiento Imputacion',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'emplazamImputacion',
                    formato: '************'
            },
                {
                    etiqueta: 'Matrícula Vehículo',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'matrVehiculo',
                    formato: '*************************'
            },
                {
                    etiqueta: 'Ubicación Técnica',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ubicacionTecnica',
                    formato: '****************************************'
            },
                {
                    etiqueta: 'clase',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'clase',
                    formato: '******************'
                },
                {
                    etiqueta: 'Código SPARD',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoSpard',
                    maxDigitos: 10
                },
                {
                    etiqueta: 'Tipo Trafo',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoTrafo',
                    formato: '***'
                },
                {
                    etiqueta: 'Importe contabilización previo',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'importContabilizPrev'
                },
                {
                    etiqueta: 'Fecha generacion',
                    filtro: true,
                    tipoCampo: 'fecha',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fechaGeneracion'
                },
                {
                    etiqueta: 'Valor contable',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorContable',
                    maxDigitos: 20
                },
                {
                    etiqueta: 'Desmantelado',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'desmantelado',
                    formato: '**'
                },
                {
                    etiqueta: 'Fecha Desmantelado',
                    filtro: true,
                    tipoCampo: 'fecha',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fechaDesmantelado'
                },
                {
                    etiqueta: 'Orden mantenimiento',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ordenMantenimiento',
                    maxDigitos: 10
                },
                {
                    etiqueta: 'Grafo',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grafo',
                    maxDigitos: 10
                }, 
                {
                    etiqueta: 'Validació Brafo',
                    filtro: true,
                    tipoCampo: 'mascara',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'validacionBrafo',
                    formato: '**'
                },
                {
                    etiqueta: 'Código Equipo',
                    filtro: true,
                    tipoCampo: 'numero',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoEquipo',
                    maxDigitos: 10
                }
            ]
        },
        validacion: {
            titulo: 'Parametrización de validación',
            url: 'validacion',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta: 'Identificador',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
                }, {
                    etiqueta: 'Nombre Campo',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'campo'
                }, {
                    etiqueta: 'Equipo',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'equipo'
                }, {
                    etiqueta: 'Permiso',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'permiso'
                }
            ]
        },
        plantilla: {
            titulo: 'Plantilla',
            url: 'plantilla',
            agregar: false,
            selector: true,
            global: {
                campo: 'alcance',
                etiqueta: 'Alcance'
            },
            masivo: [
            {
                titulo: 'Reporte',
                icono: '',
                campo: 'validacion',
                valor: 'R'
            },
            {
                titulo: 'Reporte para otra vigencia',
                icono: '',
                campo: 'validacion',
                valor: 'U',
                campoObservacion: 'anoReporte',
                textoObservacion: 'Escriba el año en el que será reportado',
                validacion: (value: any) => {
                    return value && !isNaN(value) && value < 10000 && value > 0;
                }
            },
            {
                titulo: 'No reconocido',
                icono: '',
                campo: 'validacion',
                valor: 'N',
                campoObservacion: 'observacionRechazo',
                textoObservacion: 'Escriba por favor el motivo del no reconocimiento'
            }
            ],
            acciones: [
                {
                    rol: CARGAR_PLANTILLA_CAPITALIZACION,
                    titulo: 'Cargar plantilla',
                    icono: 'fa-book',
                    accion: async (callback: (mensaje: string) => void) => {
                        
                    },
                    urlUpload: `${url}/plantilla/upload`
                },
                {
                    rol: ENVIAR_INVENTARIO,
                    titulo: 'Generar Inventario',
                    icono: 'fa-excel',
                    accion: async (callback: (mensaje: string) => void, alcance:string = '') => {
                        await axios.get(url + '/plantilla/generar-inventario?alcance='+alcance).then(data => {
                            if(data.data?.mensaje) {
                                callback(data.data.mensaje)
                            }
                        }, rechazo => {
                            const mensaje = ((rechazo.mensaje ?? rechazo.data?.mensaje) ?? rechazo.response?.mensaje) ?? rechazo.response?.data?.mensaje;
                            console.log(rechazo, mensaje);
                            if(mensaje) {
                                callback(mensaje);
                            }
                        });
                    }
                },
                {
                    rol: ENVIAR_INVENTARIO,
                    titulo: 'Rechazar Plantilla',
                    icono: 'fa-hand',
                    accion: async (callback: (mensaje: string) => void, alcance:string = '') => {
                        let prompt = window.prompt('Escriba el motivo del rechazo');
                        await axios.get(`${url}/plantilla/rechazar?alcance=${alcance}&motivo=${prompt}`).then(data => {
                            if(data.data?.mensaje) {
                                callback(data.data.mensaje)
                            }
                        }, rechazo => {
                            const mensaje = ((rechazo.mensaje ?? rechazo.data?.mensaje) ?? rechazo.response?.mensaje) ?? rechazo.response?.data?.mensaje;
                            console.log(rechazo, mensaje);
                            if(mensaje) {
                                callback(mensaje);
                            }
                        });
                    }
                },
            ],
            campos: [
                {
                    etiqueta:'Id',
                    valor: '',
                    filtro: true,
                    deshabilitado: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
            },
                {
                    etiqueta:'Grafo',
                    valor: '',
                    filtro: true,
                    deshabilitado: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grafo'
            },
                {
                    etiqueta:'Estado Validación',
                    // valor: '',
                    filtro: true,
                    deshabilitado: true,
                    tipoCampo: 'dropdown',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'validacion',
                    opciones: [
                        {
                            nombre: 'Pendiente Validación',
                            valor: 'P'
                        },
                        {
                            nombre: 'Reporte',
                            valor: 'R'
                        },
                        {
                            nombre: 'No Reconocido',
                            valor: 'N'
                        },
                        {
                            nombre: 'Rechazado',
                            valor: 'X'
                        },
                        {
                            nombre: 'Otras vigencias',
                            valor: 'U'
                        }
                    ]
            },
                {
                    etiqueta:'Denominacion Activo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'denominacionActivo'
            },
                {
                    etiqueta:'Formato Creg',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'formatoCreg'
            },
                {
                    etiqueta:'Estado Activo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estadoActivo'
            },
                {
                    etiqueta:'Tipo Inversion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoInversion'
            },
                {
                    etiqueta:'Unidad Constructiva',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'unidadConstructiva'
            },
                {
                    etiqueta:'Comp',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'comp'
            },
                {
                    etiqueta:'Cantidad Activo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidadActivo'
            },
                {
                    etiqueta:'Numero Hilos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroHilos'
            },
                {
                    etiqueta:'Cantidad Uc',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidadUc'
            },
                {
                    etiqueta:'Unidad Medida',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'unidadMedida'
            },
                {
                    etiqueta:'Factor Catenaria',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'factorCatenaria'
            },
                {
                    etiqueta:'Km Conductor',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'kmConductor'
            },
                {
                    etiqueta:'Sector',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sector'
            },
                {
                    etiqueta:'Municipio',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'municipio'
            },
                {
                    etiqueta:'Codigo Linea',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoLinea'
            },
                {
                    etiqueta:'Subestacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'subestacion'
            },
                {
                    etiqueta:'Cod Nodo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codNodo'
            },
                {
                    etiqueta:'Numero Estructuras',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroEstructuras'
            },
                {
                    etiqueta:'Latitud Inicial',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitudInicial'
            },
                {
                    etiqueta:'Longitud Inicial',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitudInicial'
            },
                {
                    etiqueta:'Altitud Inicial',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'altitudInicial'
            },
                {
                    etiqueta:'Latitud Final',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitudFinal'
            },
                {
                    etiqueta:'Longitud Final',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitudFinal'
            },
                {
                    etiqueta:'Altitud Final',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'altitudFinal'
            },
                {
                    etiqueta:'Fecha EntradaOperacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fechaEntradaOperacion'
            },
                {
                    etiqueta:'Observaciones',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'observaciones'
            },
                {
                    etiqueta:'Valor Uc',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorUc'
            },
                {
                    etiqueta:'Valor UcCreada',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorUcCreada'
            },
                {
                    etiqueta:'Activo EnCurso',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'activoEnCurso'
            },
                {
                    etiqueta:'Sn',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sn'
            },
                {
                    etiqueta:'Valor Adquisicion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorAdquisicion'
            },
                {
                    etiqueta:'Descriptor',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'descriptor'
            },
                {
                    etiqueta:'Voltaje Operacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'voltajeOperacion'
            },
                {
                    etiqueta:'Tension Nominal',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionNominal'
            },
                {
                    etiqueta:'Impedancias',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'impedancias'
            },
                {
                    etiqueta:'Resistencias',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'resistencias'
            },
                {
                    etiqueta:'Corriente Nominal',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrienteNominal'
            },
                {
                    etiqueta:'Material',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'material'
            },
                {
                    etiqueta:'Tipo Conexion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoConexion'
            },
                {
                    etiqueta:'Numero Fases',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroFases'
            },
                {
                    etiqueta:'Fase Alimentacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'faseAlimentacion'
            },
                {
                    etiqueta:'Calibre ConductorR',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreConductorR'
            },
                {
                    etiqueta:'Calibre ConductorS',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreConductorS'
            },
                {
                    etiqueta:'Calibre ConductorT',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreConductorT'
            },
                {
                    etiqueta:'Calibre ConductorN',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreConductorN'
            },
                {
                    etiqueta:'Conductor Ap',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'conductorAp'
            },
                {
                    etiqueta:'Porcentaje Conductores',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'porcentajeConductores'
            },
                {
                    etiqueta:'Disposicion Circuito',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'disposicionCircuito'
            },
                {
                    etiqueta:'Reactancia',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'reactancia'
            },
                {
                    etiqueta:'Susceptancia',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'susceptancia'
            },
                {
                    etiqueta:'Tipo Conductor',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoConductor'
            },
                {
                    etiqueta:'Circuitos Estructura',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'circuitosEstructura'
            },
                {
                    etiqueta:'Corriente Primaria',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrientePrimaria'
            },
                {
                    etiqueta:'Corriente Secundaria',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrienteSecundaria'
            },
                {
                    etiqueta:'Tipo Fibra',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoFibra'
            },
                {
                    etiqueta:'Sistema PuestaTierra',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sistemaPuestaTierra'
            },
                {
                    etiqueta:'Senalizacion Seguridad',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'senalizacionSeguridad'
            },
                {
                    etiqueta:'Peso',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'peso'
            },
                {
                    etiqueta:'Altura Apoyo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'alturaApoyo'
            },
                {
                    etiqueta:'Codigo TipoEstructura',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoTipoEstructura'
            },
                {
                    etiqueta:'Resistencia Ruptura',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'resistenciaRuptura'
            },
                {
                    etiqueta:'Funcion Estructura',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'funcionEstructura'
            },
                {
                    etiqueta:'Numero Apoyos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroApoyos'
            },
                {
                    etiqueta:'Porcentaje Apoyos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'porcentajeApoyos'
            },
                {
                    etiqueta:'Tipo Apoyo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoApoyo'
            },
                {
                    etiqueta:'Cuerpos Apoyo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cuerposApoyo'
            },
                {
                    etiqueta:'Cantidad DeDuctos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidadDeDuctos'
            },
                {
                    etiqueta:'Diametro Ductos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'diametroDuctos'
            },
                {
                    etiqueta:'Corriente Cortocircuito',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrienteCortocircuito'
            },
                {
                    etiqueta:'Ano Fabricacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'anoFabricacion'
            },
                {
                    etiqueta:'Bil',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'bil'
            },
                {
                    etiqueta:'Tipo Aislamiento',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoAislamiento'
            },
                {
                    etiqueta:'Estado Operativo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estadoOperativo'
            },
                {
                    etiqueta:'Contador Operaciones',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'contadorOperaciones'
            },
                {
                    etiqueta:'Serie Equipos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'serieEquipos'
            },
                {
                    etiqueta:'Marca',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'marca'
            },
                {
                    etiqueta:'Capacidad Nominal',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capacidadNominal'
            },
                {
                    etiqueta:'Tipo Refrigeracion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoRefrigeracion'
            },
                {
                    etiqueta:'Caracterizacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'caracterizacion'
            },
                {
                    etiqueta:'Relacion Transformacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'relacionTransformacion'
            },
                {
                    etiqueta:'Volumen Aceite',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'volumenAceite'
            },
                {
                    etiqueta:'Tipo Nucleo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoNucleo'
            },
                {
                    etiqueta:'Medio Aislante',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'medioAislante'
            },
                {
                    etiqueta:'Numero PosicionesTaps',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroPosicionesTaps'
            },
                {
                    etiqueta:'Paso Tap',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'pasoTap'
            },
                {
                    etiqueta:'Tap Nominal',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tapNominal'
            },
                {
                    etiqueta:'Tension NominalAlta',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionNominalAlta'
            },
                {
                    etiqueta:'Tension NominalBaja',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionNominalBaja'
            },
                {
                    etiqueta:'Tension NominalTerciario',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionNominalTerciario'
            },
                {
                    etiqueta:'Trafos Alumbrado',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'trafosAlumbrado'
            },
                {
                    etiqueta:'Num UsuariosTrafo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numUsuariosTrafo'
            },
                {
                    etiqueta:'Estado Transformador',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estadoTransformador'
            },
                {
                    etiqueta:'Grupo Calidad',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grupoCalidad'
            },
                {
                    etiqueta:'Area Especial',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'areaEspecial'
            },
                {
                    etiqueta:'Grupo Conexion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grupoConexion'
            },
                {
                    etiqueta:'Cantidad Nucleos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidadNucleos'
            },
                {
                    etiqueta:'Resistencia Dinamica',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'resistenciaDinamica'
            },
                {
                    etiqueta:'Numero Bobinas',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numeroBobinas'
            },
                {
                    etiqueta:'Capacidad Trafo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capacidadTrafo'
            },
                {
                    etiqueta:'Potencia Baja1',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'potenciaBaja1'
            },
                {
                    etiqueta:'Potencia Baja2',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'potenciaBaja2'
            },
                {
                    etiqueta:'Potencia Baja3',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'potenciaBaja3'
            },
                {
                    etiqueta:'Nivel Alta',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelAlta'
            },
                {
                    etiqueta:'Nivel Baja1',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelBaja1'
            },
                {
                    etiqueta:'Nivel Baja2',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelBaja2'
            },
                {
                    etiqueta:'Nivel Baja3',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelBaja3'
            },
                {
                    etiqueta:'Factor Secundario',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'factorSecundario'
            },
                {
                    etiqueta:'Factor Terciario',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'factorTerciario'
            },
                {
                    etiqueta:'Cantidad Bahias',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidadBahias'
            },
                {
                    etiqueta:'Burden',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'burden'
            },
                {
                    etiqueta:'Clase Medida',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'claseMedida'
            },
                {
                    etiqueta:'Polos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'polos'
            },
                {
                    etiqueta:'Tiempos Actuacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tiemposActuacion'
            },
                {
                    etiqueta:'Corriente MaxCorte',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'corrienteMaxCorte'
            },
                {
                    etiqueta:'Tipo Acometida',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoAcometida'
            },
                {
                    etiqueta:'Calibre CableGuarda',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'calibreCableGuarda'
            },
                {
                    etiqueta:'Tipo Reposicion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoReposicion'
            },
                {
                    etiqueta:'Tipo Alimentacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoAlimentacion'
            },
                {
                    etiqueta:'Version Software',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'versionSoftware'
            },
                {
                    etiqueta:'Protocolos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'protocolos'
            },
                {
                    etiqueta:'Fecha Calibracion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fechaCalibracion'
            },
                {
                    etiqueta:'Equipos Termicos',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'equiposTermicos'
            },
                {
                    etiqueta:'Propiedad',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'propiedad'
            },
                {
                    etiqueta:'Tipo Activo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoActivo'
            },
                {
                    etiqueta:'Fotografias',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'enlace',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fotografias'
            },
                {
                    etiqueta:'Ius Subestacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusSubestacion'
            },
                {
                    etiqueta:'Iul Linea',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iulLinea'
            },
                {
                    etiqueta:'Cod ElementoUc',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codElementoUc'
            },
                {
                    etiqueta:'Nivel Tension',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelTension'
            },
                {
                    etiqueta:'Configuracion Circuito',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'configuracionCircuito'
            },
                {
                    etiqueta:'Tipo Transformador',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoTransformador'
            },
                {
                    etiqueta:'Categoria Uc',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'categoriaUc'
            },
                {
                    etiqueta:'Iua TrafoPotencia',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaTrafoPotencia'
            },
                {
                    etiqueta:'Fecha SalidaOperacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fechaSalidaOperacion'
            },
                {
                    etiqueta:'Vida UtilRegulatoria',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'vidaUtilRegulatoria'
            },
                {
                    etiqueta:'Activo Construido',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'activoConstruido'
            },
                {
                    etiqueta:'Activo Reconocido',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'activoReconocido'
            },
                {
                    etiqueta:'Alternativa Valoracion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'alternativaValoracion'
            },
                {
                    etiqueta:'Area',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'area'
            },
                {
                    etiqueta:'Codigo Proyecto',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoProyecto'
            },
                {
                    etiqueta:'Costo Capital',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'costoCapital'
            },
                {
                    etiqueta:'Fraccion Costo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fraccionCosto'
            },
                {
                    etiqueta:'Horizonte Reposicion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'horizonteReposicion'
            },
                {
                    etiqueta:'Id Plan',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'idPlan'
            },
                {
                    etiqueta:'Incluido PlanInversion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'incluidoPlanInversion'
            },
                {
                    etiqueta:'Iua Provisional',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaProvisional'
            },
                {
                    etiqueta:'Iul Provisional',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iulProvisional'
            },
                {
                    etiqueta:'Ius Final',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusFinal'
            },
                {
                    etiqueta:'Ius Inicial',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusInicial'
            },
                {
                    etiqueta:'Ius Provisional',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusProvisional'
            },
                {
                    etiqueta:'Operacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'operacion'
            },
                {
                    etiqueta:'Porcentaje Uso',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'porcentajeUso'
            },
                {
                    etiqueta:'Uc SinNivelTension',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ucSinNivelTension'
            },
                {
                    etiqueta:'Remuneracion Pendiente',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'remuneracionPendiente'
            },
                {
                    etiqueta:'Ser Remplazado',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'serRemplazado'
            },
                {
                    etiqueta:'Salinidad',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'salinidad'
            },
                {
                    etiqueta:'Tipo Red',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoRed'
            },
                {
                    etiqueta:'Capitulo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capitulo'
            },
                {
                    etiqueta:'Sistema',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sistema'
            },
                {
                    etiqueta:'Denominacion Subestacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'denominacionSubestacion'
            },
                {
                    etiqueta:'Configuracion Subestacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'configuracionSubestacion'
            },
                {
                    etiqueta:'Tipo Subestacion',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoSubestacion'
            },
                {
                    etiqueta:'Iul Inicial',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iulInicial'
                    },
                    {
                        etiqueta:'Observación rechazo',
                        valor: '',
                        filtro: true,
                        tipoCampo: 'input text',
                        icono: 'fa-solid fa-user',
                        crear: true,
                        nombreCampo: 'observacionRechazo'
                    },
                    {
                        etiqueta: 'Valor contable',
                        filtro: true,
                        tipoCampo: 'numero',
                        icono: 'fa-solid fa-user',
                        crear: true,
                        nombreCampo: 'valorContable',
                        maxDigitos: 20
                    },
                    {
                        etiqueta: 'Año real entrada en operacion',
                        valor: '',
                        filtro: true,
                        tipoCampo: 'input text',
                        icono: 'fa-solid fa-user',
                        crear: true,
                        nombreCampo: 'AñoRealEnOperacion'
                    },
                    {
                        etiqueta: 'Mes real entrada en operacion',
                        filtro: true,
                        tipoCampo: 'input text',
                        icono: 'fa-solid fa-user',
                        crear: true,
                        nombreCampo: 'MesRealEnOperacion'
                    },
                    {
                        etiqueta: 'Descripcion soporte',
                        valor: '',
                        filtro: true,
                        tipoCampo: 'input text',
                        icono: 'fa-solid fa-user',
                        crear: true,
                        nombreCampo: 'DescripcionSoporte'
                    },
            ]
        },
        brafo: {
            titulo: 'Brafo',
            url: 'brafo',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta:'Id',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
            },
                {
                    etiqueta:'Formato',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'formato'
            },
                {
                    etiqueta:'Tipo Inventario',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoInventario'
            },
                {
                    etiqueta:'Iua Ajustado',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaAjustado'
            },
                {
                    etiqueta:'Uc Asimilida',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ucAsimilida'
            },
                {
                    etiqueta:'Cr',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cr'
            },
                {
                    etiqueta:'Pu',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'pu'
            },
                {
                    etiqueta:'Fu',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fu'
            },
                {
                    etiqueta:'Rpp',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'rpp'
            },
                {
                    etiqueta:'Cra',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cra'
            },
                {
                    etiqueta:'Vu',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'vu'
            },
                {
                    etiqueta:'Ar',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ar'
            },
                {
                    etiqueta:'Uc Especial',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ucEspecial'
            },
                {
                    etiqueta:'Categoria',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'categoria'
            },
                {
                    etiqueta:'Ano Salida',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'anoSalida'
            },
                {
                    etiqueta:'Iua Elemento',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaElemento'
            },
                {
                    etiqueta:'Cod Elemento',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codElemento'
            },
                {
                    etiqueta:'Cantidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidad'
            },
                {
                    etiqueta:'Iua',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iua'
            },
                {
                    etiqueta:'Iul',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iul'
            },
                {
                    etiqueta:'Cod Transformador',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codTransformador'
            },
                {
                    etiqueta:'Num Serie',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numSerie'
            },
                {
                    etiqueta:'Sui',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sui'
            },
                {
                    etiqueta:'Capacidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capacidad'
            },
                {
                    etiqueta:'Num Fases',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numFases'
            },
                {
                    etiqueta:'Tipo ActivoNuevo',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoActivoNuevo'
            },
                {
                    etiqueta:'Alumbrado Publico',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'alumbradoPublico'
            },
                {
                    etiqueta:'Ubicacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ubicacion'
            },
                {
                    etiqueta:'Grupo Calidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grupoCalidad'
            },
                {
                    etiqueta:'Cod Dane',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codDane'
            },
                {
                    etiqueta:'Ano Entrada',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'anoEntrada'
            },
                {
                    etiqueta:'Salinidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'salinidad'
            },
                {
                    etiqueta:'Observaciones',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'observaciones'
            },
                {
                    etiqueta:'Unidad Constructiva',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'unidadConstructiva'
            },
                {
                    etiqueta:'Num Usuarios',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numUsuarios'
            },
                {
                    etiqueta:'Longitud',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitud'
            },
                {
                    etiqueta:'Tipo Red',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoRed'
            },
                {
                    etiqueta:'Tipo Reposicion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoReposicion'
            },
                {
                    etiqueta:'Porcentaje Apoyos',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'porcentajeApoyos'
            },
                {
                    etiqueta:'Porcentaje Conductores',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'porcentajeConductores'
            },
                {
                    etiqueta:'Num Apoyos',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numApoyos'
            },
                {
                    etiqueta:'Nom Se',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nomSe'
            },
                {
                    etiqueta:'Grafo',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grafo'
            },
                {
                    etiqueta:'Item',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'item'
            },
                {
                    etiqueta:'Cr2019',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cr2019'
            },
                {
                    etiqueta:'Latitud Inicio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitudInicio'
            },
                {
                    etiqueta:'Longitud Inicio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitudInicio'
            },
                {
                    etiqueta:'Altitud Inicio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'altitudInicio'
            },
                {
                    etiqueta:'Latitud Fin',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitudFin'
            },
                {
                    etiqueta:'Longitud Fin',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitudFin'
            },
                {
                    etiqueta:'Altitud Fin',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'altitudFin'
            },
                {
                    etiqueta:'Hash',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'hash'
            },
                {
                    etiqueta:'Estado',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estado'
                    }
            ]
        },
        invtr: {
            titulo: 'Invtr',
            url: 'invtr',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta:'Id',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
            },
                {
                    etiqueta:'Formato',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'formato'
            },
                {
                    etiqueta:'Iua Ajustado',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaAjustado'
            },
                {
                    etiqueta:'Capacidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capacidad'
            },
                {
                    etiqueta:'Cr',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cr'
            },
                {
                    etiqueta:'Pu',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'pu'
            },
                {
                    etiqueta:'Fu',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fu'
            },
                {
                    etiqueta:'Rpp',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'rpp'
            },
                {
                    etiqueta:'Psn',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'psn'
            },
                {
                    etiqueta:'Plan Inversion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'planInversion'
            },
                {
                    etiqueta:'Activo Construido',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'activoConstruido'
            },
                {
                    etiqueta:'Causa NoEjecusion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'causaNoEjecusion'
            },
                {
                    etiqueta:'Iua Reemplazado',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaReemplazado'
            },
                {
                    etiqueta:'Iua Elemento',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaElemento'
            },
                {
                    etiqueta:'Cod Elemento',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codElemento'
            },
                {
                    etiqueta:'Cantidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidad'
            },
                {
                    etiqueta:'Nombre Subestacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nombreSubestacion'
            },
                {
                    etiqueta:'Grafo',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grafo'
            },
                {
                    etiqueta:'Item',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'item'
            },
                {
                    etiqueta:'Costo2019',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'costo2019'
            },
                {
                    etiqueta:'Uc',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'uc'
            },
                {
                    etiqueta:'Categoria',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'categoria'
            },
                {
                    etiqueta:'Denon Categoria',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'denonCategoria'
            },
                {
                    etiqueta:'Tipo Inversion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoInversion'
            },
                {
                    etiqueta:'Codigo Dane',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoDane'
            },
                {
                    etiqueta:'Hash',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'hash'
            },
                {
                    etiqueta:'Estado',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estado'
                }
            ]
        },
        inva: {
            titulo: 'Inva',
            url: 'inva',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta:'Id',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
            },
                {
                    etiqueta:'Formato',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'formato'
            },
                {
                    etiqueta:'Tipo Inventario',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoInventario'
            },
                {
                    etiqueta:'Cod Proyecto',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codProyecto'
            },
                {
                    etiqueta:'Iua Provisional',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaProvisional'
            },
                {
                    etiqueta:'Ius',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ius'
            },
                {
                    etiqueta:'Unidad Constructiva',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'unidadConstructiva'
            },
                {
                    etiqueta:'Porcentaje Uso',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'porcentajeUso'
            },
                {
                    etiqueta:'Rpp',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'rpp'
            },
                {
                    etiqueta:'Uia Transformaor',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'uiaTransformaor'
            },
                {
                    etiqueta:'Iul Linea',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iulLinea'
            },
                {
                    etiqueta:'Area Especial',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'areaEspecial'
            },
                {
                    etiqueta:'Salinidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'salinidad'
            },
                {
                    etiqueta:'Operacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'operacion'
            },
                {
                    etiqueta:'Ano SalidaOperacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'anoSalidaOperacion'
            },
                {
                    etiqueta:'Fraccion Costo',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'fraccionCosto'
            },
                {
                    etiqueta:'Tipo Inversion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoInversion'
            },
                {
                    etiqueta:'Iua Reemplazado',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaReemplazado'
            },
                {
                    etiqueta:'Observaciones',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'observaciones'
            },
                {
                    etiqueta:'Activo Reconocido',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'activoReconocido'
            },
                {
                    etiqueta:'Revision Creg',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'revisionCreg'
            },
                {
                    etiqueta:'Area Reconocida',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'areaReconocida'
            },
                {
                    etiqueta:'Factor Secundario',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'factorSecundario'
            },
                {
                    etiqueta:'Factor Terciario',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'factorTerciario'
            },
                {
                    etiqueta:'Str Construccion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'strConstruccion'
            },
                {
                    etiqueta:'Ano EntradaOperacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'anoEntradaOperacion'
            },
                {
                    etiqueta:'Iua Ajustado',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaAjustado'
            },
                {
                    etiqueta:'Plan Inversion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'planInversion'
            },
                {
                    etiqueta:'Cantidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'cantidad'
            },
                {
                    etiqueta:'Num Conductores',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'numConductores'
            },
                {
                    etiqueta:'Sobrepuesto',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sobrepuesto'
            },
                {
                    etiqueta:'Cod Transformador',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codTransformador'
            },
                {
                    etiqueta:'Capacidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'capacidad'
            },
                {
                    etiqueta:'Potencia Baja1',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'potenciaBaja1'
            },
                {
                    etiqueta:'Potencia Baja2',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'potenciaBaja2'
            },
                {
                    etiqueta:'Potencia Baja3',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'potenciaBaja3'
            },
                {
                    etiqueta:'Nivel Alta',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelAlta'
            },
                {
                    etiqueta:'Nivel Baja1',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelBaja1'
            },
                {
                    etiqueta:'Nivel Baja2',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelBaja2'
            },
                {
                    etiqueta:'Nivel Baja3',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelBaja3'
            },
                {
                    etiqueta:'Relacion Transformacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'relacionTransformacion'
            },
                {
                    etiqueta:'Latitud Inicio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitudInicio'
            },
                {
                    etiqueta:'Longitud Inicio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitudInicio'
            },
                {
                    etiqueta:'Altitud Inicio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'altitudInicio'
            },
                {
                    etiqueta:'Latitud Fin',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitudFin'
            },
                {
                    etiqueta:'Longitud Fin',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitudFin'
            },
                {
                    etiqueta:'Altitud Fin',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'altitudFin'
            },
                {
                    etiqueta:'Grafo',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grafo'
            },
                {
                    etiqueta:'Item',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'item'
            },
                {
                    etiqueta:'Iua Elemento',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaElemento'
            },
                {
                    etiqueta:'Iua',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iua'
            },
                {
                    etiqueta:'Hash',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'hash'
            },
                {
                    etiqueta:'Estado',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estado'
                }
               
            ]
        },
        invaGr: {
            titulo: 'Inva Gr',
            url: 'inva_gr',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta:'Id',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
            },
                {
                    etiqueta:'Formato',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'formato'
            },
                {
                    etiqueta:'Tipo Inventario',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoInventario'
            },
                {
                    etiqueta:'Cod Proyecto',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codProyecto'
            },
                {
                    etiqueta:'Nom Proyecto',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nomProyecto'
            },
                {
                    etiqueta:'Descripcion Proyecto',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'descripcionProyecto'
            },
                {
                    etiqueta:'Nivel',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivel'
            },
                {
                    etiqueta:'Tipo Inversion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tipoInversion'
            },
                {
                    etiqueta:'Ano EntradaOperacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'anoEntradaOperacion'
            },
                {
                    etiqueta:'Municipio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'municipio'
            },
                {
                    etiqueta:'Str Construccion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'strConstruccion'
            },
                {
                    etiqueta:'Piec',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'piec'
            },
                {
                    etiqueta:'Concepto Upme',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'conceptoUpme'
            },
                {
                    etiqueta:'Observaciones',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'observaciones'
            },
                {
                    etiqueta:'Ius',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'ius'
            },
                {
                    etiqueta:'Cod Subestacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codSubestacion'
            },
                {
                    etiqueta:'Nombre',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nombre'
            },
                {
                    etiqueta:'Longitud',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'longitud'
            },
                {
                    etiqueta:'Latitud',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'latitud'
            },
                {
                    etiqueta:'Altitud',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'altitud'
            },
                {
                    etiqueta:'Area',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'area'
            },
                {
                    etiqueta:'Valor Catastral',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorCatastral'
            },
                {
                    etiqueta:'Salinidad',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'salinidad'
            },
                {
                    etiqueta:'Operacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'operacion'
            },
                {
                    etiqueta:'Iul',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iul'
            },
                {
                    etiqueta:'Cod Linea',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codLinea'
            },
                {
                    etiqueta:'Ius Inicial',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusInicial'
            },
                {
                    etiqueta:'Ius Final',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iusFinal'
            },
                {
                    etiqueta:'Tension Operacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'tensionOperacion'
            },
                {
                    etiqueta:'Nivel Tension',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nivelTension'
            },
                {
                    etiqueta:'Plan Inversion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'planInversion'
            },
                {
                    etiqueta:'Iua Trafo',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'iuaTrafo'
            },
                {
                    etiqueta:'Hash',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'hash'
            },
                {
                    etiqueta:'Estado',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'estado'
                }
            ]
        },
        general: {
            titulo: 'General',
            url: 'general',
            agregar: true,
            editar: true,
            campos: [
                {
                    etiqueta:'Id',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
                },
                {
                    etiqueta:'Formato',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'formato'
                },
                {
                    etiqueta:'Grafo',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'grafo'
                },
                {
                    etiqueta:'Contrato',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'contrato'
                },
                {
                    etiqueta:'Codigo Proyecto',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoProyecto'
                },
                {
                    etiqueta:'Nombre Proyecto',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'nombreProyecto'
                },
                {
                    etiqueta:'Ano Operacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'anoOperacion'
                },
                {
                    etiqueta:'Municipio',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'municipio'
                },
                {
                    etiqueta:'Piec',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'piec'
                },
                {
                    etiqueta:'Faer',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'faer'
                },
                {
                    etiqueta:'Concepto Creg',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'conceptoCreg'
                },
                {
                    etiqueta:'Subestacion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'subestacion'
                },
                {
                    etiqueta:'Se',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'se'
                },
                {
                    etiqueta:'Codigo Linea',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'codigoLinea'
                },
                {
                    etiqueta:'Observaciones',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'observaciones'
                },
                {
                    etiqueta:'Llave ProyAf',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'llaveProyAf'
                },
                {
                    etiqueta:'Activo Curso',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'activoCurso'
                },
                {
                    etiqueta:'Sn',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'sn'
                },
                {
                    etiqueta:'Valor Adquisicion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorAdquisicion'
                },
                {
                    etiqueta:'Valor Reestructuracion',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorReestructuracion'
                },
                {
                    etiqueta:'Valor Interventoria',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'valorInterventoria'
                },
                {
                    etiqueta:'Otros Valores',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'otrosValores'
                },
                {
                    etiqueta:'Costos Financieros',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'costosFinancieros'
                },
                {
                    etiqueta:'Total Liquidar',
                    valor: '',
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'totalLiquidar'
                }
            ]
        }
    };

    parametrizacion.desmanteladoBrafo = {
        ...parametrizacion.inventario,
        titulo: 'Brafos desmantelados',
        url: 'matriz-subestacion      ',
        filtro: {
            desmantelado: 'SI',
            validacionBrafo: 'R'
        },
        masivo: [],
        acciones: [],
        global: false,
        agregar: false,
        crear: false,
        editar: false,
        selector: true,
    }
    parametrizacion.validaInventario = 
    {
        ...parametrizacion.inventario,
        titulo: 'Desmontados',
        url: 'matriz-subestacion     ',//Se dejan los espacios al final para diferenciar de otras urls de matriz-subestación y fuerce el recargado al cambioar de enlace pero tener el mismo formulario
        filtro: {
            desmantelado: 'SI',
            validacionBrafo: 'P'
        },
        global: false,
        agregar: false,
        crear: false,
        editar: false,
        selector: true,
        acciones:[
            {
                titulo: 'Exportar',
                icono: 'fa-file-excel',
                rol: DESMANTELAMIENTO_ARCGIS,
                accion: async (message: any, filter:string) => {
                    let link = url + '/matriz-subestacion/inventario?desmantelado=SI&validacionBrafo=P'
                    console.log(link);
                    window.open(link);
                }
            },
            {
                rol: DESMANTELAMIENTO_ARCGIS,
                titulo: 'identificadores para reporte',
                icono: 'fa-upload',
                accion: async (callback: (mensaje: string) => void) => {
                    
                },
                urlUpload: `${url}/matriz-subestacion/upload/desmontados`
            }
        ],
        masivo: [
            {
                titulo: 'Reporte',
                icono: '',
                campo: 'validacionBrafo',
                valor: 'R'
        },
            {
                titulo: 'No reconocido',
                icono: '',
                campo: 'validacionBrafo',
                valor: 'N'
        },
            {
                titulo: 'Otra vigencia',
                icono: '',
                campo: 'validacionBrafo',
                valor: 'X'
            }
        ]
    };
    parametrizacion.noReconocido = 
    {
        ...parametrizacion.inventario,
        titulo: 'No reconocidos',
        url: 'matriz-subestacion  ',
        filtro: {
            definitivo: 2
        },
        agregar: false,
        crear: false,
        editar: false,
        selector: true,
        acciones:[],
        masivo: [
            {
                titulo: 'Reconocer Ahora',
                icono: '',
                campo: 'definitivo',
                valor: '0'
            }
        ]
    }
    parametrizacion.otraVigencia = 
    {
        ...parametrizacion.inventario,
        titulo: 'Otras Vigencias',
        url: 'matriz-subestacion   ',
        filtro: {
            definitivo: 3
        },
        agregar: false,
        crear: false,
        editar: false,
        selector: true,
        acciones:[],
        masivo: [
            {
                titulo: 'Reportar Ahora',
                icono: '',
                campo: 'definitivo',
                valor: '0'
            }
        ]
    }
    parametrizacion.desmantelados = {
        ...parametrizacion.plantilla,
        url: 'his-plantilla',
        titulo: 'Desmantelados Capitalización',
        agregar: false,
        crear: false,
        editar: false,
        selector: false,
        filtro: {
            estadoActivo: 'Desmantelamiento'
        },
        acciones:[
            {
                titulo: 'Exportar',
                icono: 'fa-file-excel',
                rol: DESMANTELADOS_PLANTILLA,
                accion: async (message: any, filter:string) => {
                    let link = url + '/his-plantilla/desmantelados?alcance=' + filter
                    console.log(link);
                    window.open(link);
                }
            }
        ],
        masivo: []
    }

    parametrizacion.rechazados = {
        ...parametrizacion.plantilla,
        url: 'plantilla-arcgis ', // Se deja el espacio para que el sistema lo diferencie y pueda actualizar al cambio de formulario
        titulo: 'Activos Rechazados',
        agregar: false,
        crear: false,
        editar: false,
        selector: false,
        filtro: {
            validacion: 'X'
        },
        acciones:[],
        masivo: [],
    }

    parametrizacion.plantillaArcgis = {
        url: 'plantilla-arcgis',
        titulo: 'Plantilla Arcgis',
        agregar: false,
        crear: false,
        editar: true,
        selector: true,
        filtro: {},
        acciones:[
            {
                titulo: 'Mover a plantilla',
                rol: PLANTILLA,
                icono: 'fa-file-excel',
                accion: async (callback: any, filter:any=undefined) => {
                    const resultado = confirm('Se moverán los datos a plantilla de capitalización');
                    if(!resultado)
                        return;
                    await axios.post(url + '/plantilla-arcgis/mover').then(data => {
                        if(data.data?.mensaje) {
                            callback(data.data.mensaje)
                        }
                    }, (rechazo => {
                        const mensaje = ((rechazo.mensaje ?? rechazo.data?.mensaje) ?? rechazo.response?.mensaje) ?? rechazo.response?.data?.mensaje;
                        console.log(rechazo, mensaje);
                        if(mensaje) {
                            callback(mensaje);
                        }
                    }));
                }

            }
        ],
        masivo: [
            {
                titulo: 'Aceptar para plantilla',
                icono: '',
                campo: 'validacion',
                valor: 'A'
            }
        ],
        campos: [
            {
                etiqueta:'Número de orden de trabajo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                deshabilitado:true,
                nombreCampo: 'numeroOrdenTrabajo',
            },
            {
                etiqueta:'Iua de remplazo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iuaRemplazo',
            },
            {
                etiqueta:'Id Arcgis',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'idArcgis',
                deshabilitado: true,
            },
            {
                etiqueta:'Aceptado',
                valor: '',
                filtro: true,
                deshabilitado: true,
                tipoCampo: 'dropdown',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'validacion',
                opciones: [
                    {
                        nombre: 'Pendiente Aceptación',
                        valor: 'P'
                    },
                    {
                        nombre: 'Aceptado',
                        valor: 'A'
                    }
                ]
        },
            {
                etiqueta:'Denominacion Activo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'denominacionActivo'
        },
            {
                etiqueta:'Formato Creg',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'formatoCreg'
        },
            {
                etiqueta:'Estado Activo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'estadoActivo'
        },
            {
                etiqueta:'Tipo Inversion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoInversion'
        },
            {
                etiqueta:'Unidad Constructiva',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'unidadConstructiva'
        },
            {
                etiqueta:'Comp',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'comp'
        },
            {
                etiqueta:'Cantidad Activo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'cantidadActivo'
        },
            {
                etiqueta:'Numero Hilos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'numeroHilos'
        },
            {
                etiqueta:'Cantidad Uc',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'cantidadUc'
        },
            {
                etiqueta:'Unidad Medida',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'unidadMedida'
        },
            {
                etiqueta:'Factor Catenaria',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'factorCatenaria'
        },
            {
                etiqueta:'Km Conductor',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'kmConductor'
        },
            {
                etiqueta:'Sector',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'sector'
        },
            {
                etiqueta:'Municipio',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'municipio'
        },
            {
                etiqueta:'Codigo Linea',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'codigoLinea'
        },
            {
                etiqueta:'Subestacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'subestacion'
        },
            {
                etiqueta:'Cod Nodo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'codNodo'
        },
            {
                etiqueta:'Numero Estructuras',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'numeroEstructuras'
        },
            {
                etiqueta:'Latitud Inicial',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'latitudInicial'
        },
            {
                etiqueta:'Longitud Inicial',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'longitudInicial'
        },
            {
                etiqueta:'Altitud Inicial',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'altitudInicial'
        },
            {
                etiqueta:'Latitud Final',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'latitudFinal'
        },
            {
                etiqueta:'Longitud Final',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'longitudFinal'
        },
            {
                etiqueta:'Altitud Final',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'altitudFinal'
        },
            {
                etiqueta:'Fecha EntradaOperacion',
                valor: '',
                filtro: true,
                tipoCampo: 'fecha',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'fechaEntradaOperacion',
                formato: 'dd/mm/yyyy',
        },
            {
                etiqueta:'Observaciones',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'observaciones'
        },
            {
                etiqueta:'Valor Uc',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'valorUc'
        },
            {
                etiqueta:'Valor UcCreada',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'valorUcCreada'
        },
            {
                etiqueta:'Activo EnCurso',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'activoEnCurso'
        },
            {
                etiqueta:'Valor Adquisicion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'valorAdquisicion'
        },
            {
                etiqueta:'Descriptor',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'descriptor'
        },
            {
                etiqueta:'Voltaje Operacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'voltajeOperacion'
        },
            {
                etiqueta:'Tension Nominal',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tensionNominal'
        },
            {
                etiqueta:'Impedancias',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'impedancias'
        },
            {
                etiqueta:'Resistencias',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'resistencias'
        },
            {
                etiqueta:'Corriente Nominal',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'corrienteNominal'
        },
            {
                etiqueta:'Material',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'material'
        },
            {
                etiqueta:'Tipo Conexion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoConexion'
        },
            {
                etiqueta:'Numero Fases',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'numeroFases'
        },
            {
                etiqueta:'Fase Alimentacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'faseAlimentacion'
        },
            {
                etiqueta:'Calibre ConductorR',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'calibreConductorR'
        },
            {
                etiqueta:'Calibre ConductorS',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'calibreConductorS'
        },
            {
                etiqueta:'Calibre ConductorT',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'calibreConductorT'
        },
            {
                etiqueta:'Calibre ConductorN',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'calibreConductorN'
        },
            {
                etiqueta:'Conductor Ap',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'conductorAp'
        },
            {
                etiqueta:'Porcentaje Conductores',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'porcentajeConductores'
        },
            {
                etiqueta:'Disposicion Circuito',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'disposicionCircuito'
        },
            {
                etiqueta:'Reactancia',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'reactancia'
        },
            {
                etiqueta:'Susceptancia',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'susceptancia'
        },
            {
                etiqueta:'Tipo Conductor',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoConductor'
        },
            {
                etiqueta:'Circuitos Estructura',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'circuitosEstructura'
        },
            {
                etiqueta:'Corriente Primaria',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'corrientePrimaria'
        },
            {
                etiqueta:'Corriente Secundaria',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'corrienteSecundaria'
        },
            {
                etiqueta:'Tipo Fibra',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoFibra'
        },
            {
                etiqueta:'Sistema PuestaTierra',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'sistemaPuestaTierra'
        },
            {
                etiqueta:'Senalizacion Seguridad',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'senalizacionSeguridad'
        },
            {
                etiqueta:'Peso',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'peso'
        },
            {
                etiqueta:'Altura Apoyo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'alturaApoyo'
        },
            {
                etiqueta:'Codigo TipoEstructura',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'codigoTipoEstructura'
        },
            {
                etiqueta:'Resistencia Ruptura',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'resistenciaRuptura'
        },
            {
                etiqueta:'Funcion Estructura',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'funcionEstructura'
        },
            {
                etiqueta:'Numero Apoyos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'numeroApoyos'
        },
            {
                etiqueta:'Porcentaje Apoyos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'porcentajeApoyos'
        },
            {
                etiqueta:'Tipo Apoyo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoApoyo'
        },
            {
                etiqueta:'Cuerpos Apoyo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'cuerposApoyo'
        },
            {
                etiqueta:'Cantidad DeDuctos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'cantidadDeDuctos'
        },
            {
                etiqueta:'Diametro Ductos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'diametroDuctos'
        },
            {
                etiqueta:'Corriente Cortocircuito',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'corrienteCortocircuito'
        },
            {
                etiqueta:'Ano Fabricacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'anoFabricacion'
        },
            {
                etiqueta:'Bil',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'bil'
        },
            {
                etiqueta:'Tipo Aislamiento',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoAislamiento'
        },
            {
                etiqueta:'Estado Operativo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'estadoOperativo'
        },
            {
                etiqueta:'Contador Operaciones',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'contadorOperaciones'
        },
            {
                etiqueta:'Serie Equipos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'serieEquipos'
        },
            {
                etiqueta:'Marca',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'marca'
        },
            {
                etiqueta:'Capacidad Nominal',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'capacidadNominal'
        },
            {
                etiqueta:'Tipo Refrigeracion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoRefrigeracion'
        },
            {
                etiqueta:'Caracterizacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'caracterizacion'
        },
            {
                etiqueta:'Relacion Transformacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'relacionTransformacion'
        },
            {
                etiqueta:'Volumen Aceite',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'volumenAceite'
        },
            {
                etiqueta:'Tipo Nucleo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoNucleo'
        },
            {
                etiqueta:'Medio Aislante',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'medioAislante'
        },
            {
                etiqueta:'Numero PosicionesTaps',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'numeroPosicionesTaps'
        },
            {
                etiqueta:'Paso Tap',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'pasoTap'
        },
            {
                etiqueta:'Tap Nominal',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tapNominal'
        },
            {
                etiqueta:'Tension NominalAlta',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tensionNominalAlta'
        },
            {
                etiqueta:'Tension NominalBaja',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tensionNominalBaja'
        },
            {
                etiqueta:'Tension NominalTerciario',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tensionNominalTerciario'
        },
            {
                etiqueta:'Trafos Alumbrado',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'trafosAlumbrado'
        },
            {
                etiqueta:'Num UsuariosTrafo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'numUsuariosTrafo'
        },
            {
                etiqueta:'Estado Transformador',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'estadoTransformador'
        },
            {
                etiqueta:'Grupo Calidad',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'grupoCalidad'
        },
            {
                etiqueta:'Area Especial',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'areaEspecial'
        },
            {
                etiqueta:'Grupo Conexion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'grupoConexion'
        },
            {
                etiqueta:'Cantidad Nucleos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'cantidadNucleos'
        },
            {
                etiqueta:'Resistencia Dinamica',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'resistenciaDinamica'
        },
            {
                etiqueta:'Numero Bobinas',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'numeroBobinas'
        },
            {
                etiqueta:'Capacidad Trafo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'capacidadTrafo'
        },
            {
                etiqueta:'Potencia Baja1',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'potenciaBaja1'
        },
            {
                etiqueta:'Potencia Baja2',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'potenciaBaja2'
        },
            {
                etiqueta:'Potencia Baja3',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'potenciaBaja3'
        },
            {
                etiqueta:'Nivel Alta',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'nivelAlta'
        },
            {
                etiqueta:'Nivel Baja1',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'nivelBaja1'
        },
            {
                etiqueta:'Nivel Baja2',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'nivelBaja2'
        },
            {
                etiqueta:'Nivel Baja3',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'nivelBaja3'
        },
            {
                etiqueta:'Factor Secundario',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'factorSecundario'
        },
            {
                etiqueta:'Factor Terciario',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'factorTerciario'
        },
            {
                etiqueta:'Cantidad Bahias',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'cantidadBahias'
        },
            {
                etiqueta:'Burden',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'burden'
        },
            {
                etiqueta:'Clase Medida',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'claseMedida'
        },
            {
                etiqueta:'Polos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'polos'
        },
            {
                etiqueta:'Tiempos Actuacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tiemposActuacion'
        },
            {
                etiqueta:'Corriente MaxCorte',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'corrienteMaxCorte'
        },
            {
                etiqueta:'Tipo Acometida',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoAcometida'
        },
            {
                etiqueta:'Calibre CableGuarda',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'calibreCableGuarda'
        },
            {
                etiqueta:'Tipo Reposicion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoReposicion'
        },
            {
                etiqueta:'Tipo Alimentacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoAlimentacion'
        },
            {
                etiqueta:'Version Software',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'versionSoftware'
        },
            {
                etiqueta:'Protocolos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'protocolos'
        },
            {
                etiqueta:'Fecha Calibracion',
                valor: '',
                filtro: true,
                tipoCampo: 'fecha',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'fechaCalibracion',
                formato: 'dd/mm/yyyy',
        },
            {
                etiqueta:'Equipos Termicos',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'equiposTermicos'
        },
            {
                etiqueta:'Propiedad',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'propiedad'
        },
            {
                etiqueta:'Tipo Activo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoActivo'
        },
            {
                etiqueta:'Fotografias',
                valor: '',
                filtro: true,
                tipoCampo: 'enlace',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'fotografias'
        },
            {
                etiqueta:'Ius Subestacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iusSubestacion'
        },
            {
                etiqueta:'Iul Linea',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iulLinea'
        },
            {
                etiqueta:'Cod ElementoUc',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'codElementoUc'
        },
            {
                etiqueta:'Nivel Tension',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'nivelTension'
        },
            {
                etiqueta:'Configuracion Circuito',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'configuracionCircuito'
        },
            {
                etiqueta:'Tipo Transformador',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoTransformador'
        },
            {
                etiqueta:'Categoria Uc',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'categoriaUc'
        },
            {
                etiqueta:'Iua TrafoPotencia',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iuaTrafoPotencia'
        },
            {
                etiqueta:'Fecha SalidaOperacion',
                valor: '',
                filtro: true,
                tipoCampo: 'fecha',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'fechaSalidaOperacion',
                formato: 'dd/mm/yyyy',
        },
            {
                etiqueta:'Vida UtilRegulatoria',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'vidaUtilRegulatoria'
        },
            {
                etiqueta:'Activo Construido',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'activoConstruido'
        },
            {
                etiqueta:'Activo Reconocido',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'activoReconocido'
        },
            {
                etiqueta:'Alternativa Valoracion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'alternativaValoracion'
        },
            {
                etiqueta:'Area',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'area'
        },
            {
                etiqueta:'Codigo Proyecto',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'codigoProyecto'
        },
            {
                etiqueta:'Costo Capital',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'costoCapital'
        },
            {
                etiqueta:'Fraccion Costo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'fraccionCosto'
        },
            {
                etiqueta:'Horizonte Reposicion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'horizonteReposicion'
        },
            {
                etiqueta:'Id Plan',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'idPlan'
        },
            {
                etiqueta:'Incluido PlanInversion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'incluidoPlanInversion'
        },
            {
                etiqueta:'Iua Provisional',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iuaProvisional'
        },
            {
                etiqueta:'Iul Provisional',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iulProvisional'
        },
            {
                etiqueta:'Ius Final',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iusFinal'
        },
            {
                etiqueta:'Ius Inicial',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iusInicial'
        },
            {
                etiqueta:'Ius Provisional',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iusProvisional'
        },
            {
                etiqueta:'Operacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'operacion'
        },
            {
                etiqueta:'Porcentaje Uso',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'porcentajeUso'
        },
            {
                etiqueta:'Uc SinNivelTension',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'ucSinNivelTension'
        },
            {
                etiqueta:'Remuneracion Pendiente',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'remuneracionPendiente'
        },
            {
                etiqueta:'Ser Remplazado',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'serRemplazado'
        },
            {
                etiqueta:'Salinidad',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'salinidad'
        },
            {
                etiqueta:'Tipo Red',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoRed'
        },
            {
                etiqueta:'Capitulo',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'capitulo'
        },
            {
                etiqueta:'Sistema',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'sistema'
        },
            {
                etiqueta:'Denominacion Subestacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'denominacionSubestacion'
        },
            {
                etiqueta:'Configuracion Subestacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'configuracionSubestacion'
        },
            {
                etiqueta:'Tipo Subestacion',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'tipoSubestacion'
        },
            {
                etiqueta:'Iul Inicial',
                valor: '',
                filtro: true,
                tipoCampo: 'input text',
                icono: 'fa-solid fa-user',
                crear: true,
                nombreCampo: 'iulInicial'
                },
                {
                    etiqueta:'Observación rechazo',
                    valor: '',
                    filtro: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'observacionRechazo'
                },
                {
                    etiqueta:'Id',
                    valor: '',
                    filtro: true,
                    deshabilitado: true,
                    tipoCampo: 'input text',
                    icono: 'fa-solid fa-user',
                    crear: true,
                    nombreCampo: 'id'
                },
                
        ]
    }

    const formularios = ref(parametrizacion);
    const rutaFormulario = ref({
        predeterminado: 'inventario',
        listado: 'listado',
        equipos: 'equipo',
        caracteristicas: 'caracteristicas',
        subestacion: 'subestacion',
        linea: 'linea',
        marcafabricante: 'marcaFabricante',
        grupocalidad: 'grupoCalidad',
        categoria: 'categoria',
        inventario: 'inventario',
        fasealimentacion: 'faseAlimentacion',
        validacion: 'validacion',
        plantilla: 'plantilla',
        brafo: 'brafo',
        invtr: 'invtr',
        inva: 'inva',
        invagr: 'invaGr',
        general: 'general',
        validainventario: 'validaInventario',
        noReconocido: 'noReconocido',
        otraVigencia: 'otraVigencia',
        usuario: 'usuario',
        desmantelados: 'desmantelados',
        rechazados: 'rechazados',
        plantillaArcgis: 'plantillaArcgis',
        desmanteladoBrafo: 'desmanteladoBrafo',
    });

    return {
        formularios,
        rutaFormulario,
        url,
        link
    };
});
