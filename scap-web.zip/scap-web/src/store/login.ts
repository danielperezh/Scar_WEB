import { defineStore } from "pinia";
import { ref} from "vue";
import axios  from "axios";

let link = 'http://localhost:8080';
if(location.href.indexOf('localhost')<0)
    link = `${location.protocol}//${location.hostname}:8082`


export const useLoginStore = defineStore("mainLogin", ()=>{

    const userlogin = ref({
        authenticated:false,
        loader:false,
        loadRecover:false,
        recoverSend:false,
        modalRecover:false,
        username:'',
        password:'',
        mensRecov:'Enviando el correo..',
        loginError: false,
        roles: [],
        reset:()=>{
            userlogin.value.authenticated=false;
            userlogin.value.loader=false;
            userlogin.value.loadRecover=false;
            userlogin.value.recoverSend=false;
            userlogin.value.modalRecover=false;
            userlogin.value.username='';
            userlogin.value.password='';
            userlogin.value.mensRecov='';
            userlogin.value.roles = []
        }
    })

    const data = ref({
        name:'',
        lastName:'',
        avatar:'',
        role:'',
        usuario: '',
        contrasena: '',
        reset:()=>{
           data.value.role='';
           data.value.lastName='';
           data.value.name=''
           data.value.usuario = ''
           data.value.contrasena = ''
        }

    })

    const datosUsuario = () => {
        // console.log('llamado a la api para obtener los datos de usuario')
        data.value.name='SCAP'
        data.value.lastName='Web'
    }
    const iniciarSesion = () =>{
        const url = link + '/login';
        userlogin.value.loader=true;
        let form = new FormData();
        form.append('username', data.value.usuario)
        form.append('password', data.value.contrasena)
        axios.post(url, form, {
            headers: {
                "Content-Type": "multipart/form-data",
                withCredentials: true 
              },
        }).then(response => {
            /*if(response.request?.responseUrl == url) {
                userlogin.value.loginError = true;
                userlogin.value.loader = false;
                return;
            }*/
            userlogin.value.authenticated=true
            datosUsuario()
            setTimeout(()=>{
                userlogin.value.loader=false
            },20000)
        }, error => {
            console.log(error)
        });
        setTimeout(()=>{
        },5000)
    }
    const recoverPass = () =>{
        userlogin.value.loadRecover=true
        userlogin.value.mensRecov='Enviando el correo...'
        setTimeout(()=>{
            userlogin.value.mensRecov='Correo enviado con exito!'
        },5000)
    }
    const resetRecover = () =>{
        userlogin.value.loadRecover=false
        userlogin.value.recoverSend=false
        
    }

    const getUser = () => {
        try {
            let user = JSON.parse(localStorage.getItem('user') || '');
            if(user?.roles) {
                userlogin.value.authenticated = true;
                return user;
            }
        } catch (error) {
            return '';
        }
        userlogin.value.authenticated = false;
        return '';
    }

    const setUser = (user: any) => {
        localStorage.setItem('user', JSON.stringify(user));
        return getUser();
    }

    const logout = () => {
        localStorage.removeItem('user');
        userlogin.value.authenticated = false;
    }

    const existeRol = (rol: string) => {
        let user = getUser();
        return (user.roles as Array<string>).includes(rol);
    }
    
    return {
        link,
        userlogin,
        data,
        datosUsuario,
        iniciarSesion,
        recoverPass,
        resetRecover,
        setUser,
        getUser,
        logout,
        existeRol,
    }
})
