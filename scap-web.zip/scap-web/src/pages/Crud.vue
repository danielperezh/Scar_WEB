<script setup lang="ts">
import { useLoginStore } from '@/store/login';
import Formulario from '../components/Formulario.vue'
import { useFormularioStore } from '../store/formulario'

const formularioStore: any = useFormularioStore();
const loginStore = useLoginStore();
loginStore.getUser();

const getForm = (route: any) => {
    let formulario;
    if(route in formularioStore.rutaFormulario)
        formulario = formularioStore.rutaFormulario[route];
    else if ('' == route)
        formulario = formularioStore.rutaFormulario.predeterminado;
    return formularioStore.formularios[formulario];
}
const getUrl = (route: any) => {
    let url = formularioStore.url +  '/' + getForm(route).url
    return url;
}
const getAcciones = (route: any) => {
    return getForm(route).acciones || [];
}
const getMasivo = (route: any) => {
    return getForm(route).masivo || [];
}

</script>
<template>
    <Formulario :data="getForm($router.currentRoute.value.params.form)" :url="getUrl($router.currentRoute.value.params.form)"
    :acciones="getAcciones($router.currentRoute.value.params.form)" :masivo="getMasivo($router.currentRoute.value.params.form)"></Formulario>
</template>
