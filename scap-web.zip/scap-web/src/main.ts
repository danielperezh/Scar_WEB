import { createApp } from "vue";
import { createPinia } from "pinia";

import App from "./App.vue";
import router from "./router";

import PrimeVue from 'primevue/config'
import ToastService from 'primevue/toastservice'

import Tooltip from 'primevue/tooltip';
import Dialog from 'primevue/dialog'
import Button from 'primevue/button'
import InputText from 'primevue/inputtext'
import Toast from 'primevue/toast'
import DataTable from 'primevue/datatable';
import Column from 'primevue/column';
import InputMask from 'primevue/inputmask';
import Listbox from 'primevue/listbox';
import Checkbox from 'primevue/checkbox';
import Password from 'primevue/password';

import './assets/custom.css'      
import 'primevue/resources/primevue.min.css'                
//import 'primeicons/primeicons.css' 

import '@fortawesome/fontawesome-free/css/all.css'
import '@fortawesome/fontawesome-free/js/all.js'

import './css/main.css'
import './css/menu.css'
import './css/toast.css'
import InputNumber from "primevue/inputnumber";
import Calendar from 'primevue/calendar';
import ConfirmationService from 'primevue/confirmationservice';
import Chips from "primevue/chips";

const app = createApp(App);

app.use(createPinia());

app.use(PrimeVue);
app.use(ToastService);
app.use(router);
app.use(ConfirmationService);
app.component('Dialog', Dialog)
app.component('Button', Button)
app.component('InputText', InputText)
app.component('Toast', Toast)
app.component('DataTable', DataTable)
app.component('Column', Column)
app.component('InputNumber', InputNumber)
app.component('InputMask', InputMask)
app.component('Calendar', Calendar)
app.component('Chips', Chips)
app.component('Listbox', Listbox)
app.component('Checkbox', Checkbox)
app.component('Password', Password)

app.directive('tooltip', Tooltip);

app.mount("#app");
