import { fileURLToPath, URL } from "url";

import { defineConfig, preview } from "vite";
import vue from "@vitejs/plugin-vue";
import vueJsx from "@vitejs/plugin-vue-jsx";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue(), vueJsx()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  server: {
    https: {
      cert: '../ebsa/star_ebsa_com_co.pem',
      key: '../ebsa/key.pem'
    },
    port: 8081,
    headers: {
      'Content-Security-Policy': "default-src https: 'unsafe-eval' 'unsafe-inline'",
      'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload',
      'X-Frame-Options': 'SAMEORIGIN',
      'X-Content-Type-Options': 'nosniff',
      'X-XSS-Protection': '1; mode=block',
      'Referrer-Policy': 'no-referrer',
      'Feature-Policy': "geolocation 'self'; microphone 'self'; camera 'self'",
      'Permissions-Policy': "geolocation=(); microphone=()",
    }
  }
})
